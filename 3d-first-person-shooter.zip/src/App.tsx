import { useEffect, useRef, useState, useCallback } from 'react';
import { PskovGame, type HudState, type GamePhase } from './game/Game';
import {
  Heart, Trophy, Skull, Zap, Shield, Crosshair, Play, RotateCcw,
  Volume2, VolumeX, GraduationCap, Target, Timer, Flame,
  ChevronRight, BookOpen, Coffee, Briefcase, MousePointer2,
  Keyboard, Award, Sparkles, AlertTriangle, Pause,
} from 'lucide-react';

interface FeedItem { id: number; text: string; kind: 'kill' | 'info' | 'bad' | 'good'; }
interface EndData { kills: number; score: number; time: number; wave: number; }

const initialHud: HudState = {
  hp: 100, maxHp: 100, kills: 0, score: 0, wave: 1, enemiesLeft: 0,
  diploma: 0, overheat: 0, overheated: false, rapid: false, shield: false,
  hitmarker: 0, hurtFlash: 0, time: 0, best: 0, killsNeeded: 30,
};

function fmtTime(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, '0')}`;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<PskovGame | null>(null);
  const [phase, setPhase] = useState<GamePhase>('menu');
  const [hud, setHud] = useState<HudState>(initialHud);
  const [feed, setFeed] = useState<FeedItem[]>([]);
  const [endData, setEndData] = useState<EndData>({ kills: 0, score: 0, time: 0, wave: 1 });
  const [muted, setMuted] = useState(false);
  const [isTouch] = useState(() => typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0));
  const feedId = useRef(0);
  const lastHudPush = useRef(0);
  const lastHudSig = useRef('');

  const pushFeed = useCallback((text: string, kind: FeedItem['kind']) => {
    const id = ++feedId.current;
    setFeed((f) => [...f.slice(-4), { id, text, kind }]);
    setTimeout(() => setFeed((f) => f.filter((x) => x.id !== id)), 4500);
  }, []);

  useEffect(() => {
    if (!canvasRef.current) return;
    const game = new PskovGame(canvasRef.current, {
      onHud: (h) => {
        const now = performance.now();
        const sig = `${h.hp}|${h.kills}|${h.wave}|${h.enemiesLeft}|${h.score}|${h.overheated}`;
        if (sig !== lastHudSig.current || now - lastHudPush.current > 120) {
          lastHudSig.current = sig;
          lastHudPush.current = now;
          setHud(h);
        } else if (now - lastHudPush.current > 400) {
          lastHudPush.current = now;
          setHud(h);
        }
      },
      onPhase: (p, data) => {
        setPhase(p);
        if ((p === 'dead' || p === 'victory') && data) setEndData(data);
      },
      onFeed: (text, kind) => pushFeed(text, kind),
    });
    gameRef.current = game;
    // один кадр-превью для фона меню
    return () => { game.dispose(); gameRef.current = null; };
  }, [pushFeed]);

  const handleStart = () => {
    gameRef.current?.start();
    setPhase('playing');
    gameRef.current?.lock();
    pushFeed('🎓 Добро пожаловать в ПсковГУ! Отстреливай преподов!', 'info');
    pushFeed('🔫 Твой ХУЕмёт-3000 уже стоит... наготове!', 'good');
  };
  const handleRestart = () => {
    gameRef.current?.restart();
    setFeed([]);
    setPhase('playing');
  };
  const handleResume = () => gameRef.current?.resume();
  const toggleMute = () => {
    const m = !muted;
    setMuted(m);
    gameRef.current?.setMuted(m);
  };
  const doJump = () => {
    window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Space' }));
    setTimeout(() => window.dispatchEvent(new KeyboardEvent('keyup', { code: 'Space' })), 120);
  };

  // touch joystick
  const joyRef = useRef<HTMLDivElement>(null);
  const joyActive = useRef(false);
  const joyCenter = useRef({ x: 0, y: 0 });
  const [joyPos, setJoyPos] = useState({ x: 0, y: 0 });
  const lookRef = useRef<number | null>(null);
  const lookLast = useRef({ x: 0, y: 0 });

  const hurtAgo = performance.now() - hud.hurtFlash;
  const hitAgo = performance.now() - hud.hitmarker;
  const showHurt = phase === 'playing' && hurtAgo < 450;
  const showHit = phase === 'playing' && hitAgo < 180;

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#0b1026] text-white select-none" style={{ fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' }}>
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" style={{ touchAction: 'none' }} />

      {/* ================= HUD ================= */}
      {(phase === 'playing' || phase === 'paused') && (
        <>
          {/* урон-виньетка */}
          <div className={`pointer-events-none absolute inset-0 transition-opacity duration-150 ${showHurt ? 'opacity-100' : 'opacity-0'}`}
            style={{ background: 'radial-gradient(ellipse at center, transparent 40%, rgba(220,38,38,0.55) 100%)' }} />
          {/* low hp pulse */}
          {hud.hp <= 30 && phase === 'playing' && (
            <div className="pointer-events-none absolute inset-0 animate-pulse"
              style={{ background: 'radial-gradient(ellipse at center, transparent 55%, rgba(220,38,38,0.4) 100%)' }} />
          )}
          {/* щит */}
          {hud.shield && (
            <div className="pointer-events-none absolute inset-0" style={{ boxShadow: 'inset 0 0 120px rgba(96,165,250,0.45)', borderRadius: 12 }} />
          )}

          {/* верхняя панель */}
          <div className="absolute left-0 right-0 top-0 flex items-start justify-between gap-2 p-3 sm:p-4">
            {/* HP */}
            <div className="w-56 sm:w-64 rounded-2xl border border-white/10 bg-black/55 p-3 backdrop-blur-md">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-sm font-black tracking-wide">
                  <Heart className={`h-4 w-4 ${hud.hp <= 30 ? 'animate-pulse text-red-500' : 'text-rose-400'}`} fill="currentColor" />
                  <span>{hud.hp}</span><span className="text-white/40 font-bold">/ {hud.maxHp}</span>
                </div>
                <div className="flex gap-1">
                  {hud.rapid && <span className="flex items-center gap-1 rounded-md bg-yellow-400/20 px-1.5 py-0.5 text-[10px] font-black text-yellow-300"><Zap className="h-3 w-3" />RAPID</span>}
                  {hud.shield && <span className="flex items-center gap-1 rounded-md bg-blue-400/20 px-1.5 py-0.5 text-[10px] font-black text-blue-300"><Shield className="h-3 w-3" />ЩИТ</span>}
                </div>
              </div>
              <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-white/10">
                <div className={`h-full rounded-full transition-all duration-200 ${hud.hp > 60 ? 'bg-gradient-to-r from-emerald-400 to-lime-300' : hud.hp > 30 ? 'bg-gradient-to-r from-amber-400 to-yellow-300' : 'bg-gradient-to-r from-red-600 to-red-400'}`}
                  style={{ width: `${(hud.hp / hud.maxHp) * 100}%` }} />
              </div>
              <div className="mt-2 flex items-center justify-between text-xs">
                <span className="flex items-center gap-1 font-bold text-amber-300"><Trophy className="h-3.5 w-3.5" />{hud.score}</span>
                <span className="flex items-center gap-1 text-white/60 font-bold"><Timer className="h-3.5 w-3.5" />{fmtTime(hud.time)}</span>
              </div>
            </div>

            {/* волна + диплом */}
            <div className="hidden sm:block w-80 rounded-2xl border border-amber-300/20 bg-black/55 p-3 text-center backdrop-blur-md">
              <div className="flex items-center justify-center gap-2 text-sm font-black">
                <BookOpen className="h-4 w-4 text-amber-300" />
                <span>ВОЛНА {hud.wave}</span>
                <span className="rounded-full bg-red-500/20 px-2 py-0.5 text-xs text-red-300">👹 {hud.enemiesLeft}</span>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <GraduationCap className="h-4 w-4 shrink-0 text-amber-300" />
                <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-gradient-to-r from-amber-500 via-yellow-300 to-emerald-300 transition-all duration-500" style={{ width: `${hud.diploma}%` }} />
                </div>
                <span className="text-xs font-black text-amber-200">{hud.diploma}%</span>
              </div>
              <div className="mt-1 text-[11px] font-bold text-white/60">ДИПЛОМ: {hud.kills}/{hud.killsNeeded} зачётов</div>
            </div>

            {/* правые кнопки */}
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center gap-1.5 rounded-xl border border-white/10 bg-black/55 px-3 py-2 text-sm font-black backdrop-blur-md">
                <Target className="h-4 w-4 text-lime-300" /> {hud.kills} <span className="text-white/40">фрагов</span>
              </div>
              <button onClick={toggleMute} className="rounded-xl border border-white/10 bg-black/55 p-2.5 backdrop-blur-md hover:bg-white/10">
                {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </button>
            </div>
          </div>

          {/* мобильная полоса диплома */}
          <div className="absolute left-3 right-3 top-[92px] sm:hidden">
            <div className="flex items-center gap-2 rounded-xl border border-amber-300/20 bg-black/55 px-3 py-1.5 backdrop-blur-md">
              <GraduationCap className="h-4 w-4 text-amber-300" />
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
                <div className="h-full rounded-full bg-gradient-to-r from-amber-500 to-emerald-300" style={{ width: `${hud.diploma}%` }} />
              </div>
              <span className="text-[11px] font-black">{hud.kills}/{hud.killsNeeded}</span>
              <span className="text-[11px] font-black text-red-300">В{hud.wave}</span>
            </div>
          </div>

          {/* прицел */}
          {phase === 'playing' && (
            <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="relative flex h-12 w-12 items-center justify-center">
                <div className={`absolute rounded-full border-2 transition-all duration-100 ${hud.overheated ? 'h-10 w-10 border-red-500' : 'h-7 w-7 border-white/90'}`} style={{ boxShadow: '0 0 8px rgba(0,0,0,0.8)' }} />
                <div className="absolute h-1.5 w-1.5 rounded-full bg-lime-300" style={{ boxShadow: '0 0 6px #a3e635' }} />
                <div className="absolute h-[2px] w-2 bg-white/90 left-1/2 top-0 -translate-x-1/2" />
                <div className="absolute h-[2px] w-2 bg-white/90 left-1/2 bottom-0 -translate-x-1/2" />
                <div className="absolute h-2 w-[2px] bg-white/90 top-1/2 left-0 -translate-y-1/2" />
                <div className="absolute h-2 w-[2px] bg-white/90 top-1/2 right-0 -translate-y-1/2" />
                {showHit && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="h-9 w-9 rotate-45 rounded-[4px] border-[3px] border-red-500" style={{ clipPath: 'polygon(0 0, 30% 0, 30% 30%, 0 30%, 0 0, 70% 70%, 70% 100%, 100% 100%, 100% 70%, 70% 70%)' }} />
                    <span className="absolute -top-6 text-xs font-black text-red-400">ПОПАЛ!</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* низ: оружие */}
          <div className="absolute bottom-3 left-1/2 w-[min(480px,92vw)] -translate-x-1/2 sm:bottom-5">
            <div className="rounded-2xl border border-pink-300/20 bg-black/60 p-3 backdrop-blur-md">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-sm font-black text-pink-300">
                    <Flame className="h-4 w-4" /> ХУЕмёт-3000 «Стояк»
                    <span className="rounded bg-pink-500/20 px-1.5 py-0.5 text-[10px] text-pink-200">∞ патроны</span>
                  </div>
                  <div className="mt-0.5 text-[11px] font-bold text-white/50">ЛКМ — огонь • SHIFT — бег • SPACE — прыжок</div>
                </div>
                <div className="text-right">
                  <div className={`text-2xl font-black ${hud.overheated ? 'animate-pulse text-red-500' : hud.overheat > 60 ? 'text-amber-300' : 'text-white'}`}>
                    {hud.overheated ? 'ПЕРЕГРЕВ!' : `${100 - hud.overheat}%`}
                  </div>
                  <div className="text-[10px] font-bold text-white/50">готовность ствола</div>
                </div>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/10">
                <div className={`h-full rounded-full transition-all duration-100 ${hud.overheat > 80 ? 'bg-red-500' : hud.overheat > 50 ? 'bg-amber-400' : 'bg-gradient-to-r from-pink-400 to-rose-300'}`} style={{ width: `${hud.overheat}%` }} />
              </div>
            </div>
          </div>

          {/* kill feed */}
          <div className="absolute right-3 top-24 flex w-64 flex-col gap-1.5 sm:top-28">
            {feed.map((f) => (
              <div key={f.id} className={`animate-[feedIn_0.25s_ease-out] rounded-xl border px-3 py-1.5 text-xs font-bold backdrop-blur-md ${f.kind === 'kill' ? 'border-lime-300/30 bg-lime-950/70 text-lime-200' : f.kind === 'bad' ? 'border-red-400/30 bg-red-950/70 text-red-200' : f.kind === 'good' ? 'border-amber-300/30 bg-amber-950/70 text-amber-200' : 'border-white/10 bg-black/60 text-white/85'}`}>
                {f.text}
              </div>
            ))}
          </div>

          {/* подсказка волны */}
          {hud.enemiesLeft === 0 && phase === 'playing' && (
            <div className="pointer-events-none absolute left-1/2 top-[22%] -translate-x-1/2 rounded-2xl border border-amber-300/30 bg-black/70 px-6 py-3 text-center backdrop-blur-md">
              <div className="animate-pulse text-lg font-black text-amber-300">ПЕРЕМЕНКА... ☕</div>
              <div className="text-xs font-bold text-white/60">Следующая волна преподов уже точит указки</div>
            </div>
          )}

          {/* touch controls */}
          {isTouch && phase === 'playing' && (
            <>
              <div className="absolute inset-y-0 right-0 w-1/2"
                style={{ touchAction: 'none' }}
                onTouchStart={(e) => { const t = e.changedTouches[0]; lookRef.current = t.identifier; lookLast.current = { x: t.clientX, y: t.clientY }; }}
                onTouchMove={(e) => {
                  for (const t of Array.from(e.changedTouches)) {
                    if (t.identifier === lookRef.current) {
                      gameRef.current?.addLook(t.clientX - lookLast.current.x, t.clientY - lookLast.current.y);
                      lookLast.current = { x: t.clientX, y: t.clientY };
                    }
                  }
                }}
                onTouchEnd={(e) => { for (const t of Array.from(e.changedTouches)) if (t.identifier === lookRef.current) lookRef.current = null; }} />
              <div ref={joyRef} className="absolute bottom-28 left-4 z-10 h-32 w-32 rounded-full border-2 border-white/20 bg-white/5 backdrop-blur-sm"
                onTouchStart={(e) => {
                  const t = e.changedTouches[0];
                  joyActive.current = true;
                  joyCenter.current = { x: t.clientX, y: t.clientY };
                }}
                onTouchMove={(e) => {
                  if (!joyActive.current) return;
                  const t = e.changedTouches[0];
                  let dx = (t.clientX - joyCenter.current.x) / 40;
                  let dy = (t.clientY - joyCenter.current.y) / 40;
                  dx = Math.max(-1, Math.min(1, dx)); dy = Math.max(-1, Math.min(1, dy));
                  setJoyPos({ x: dx, y: dy });
                  gameRef.current?.setTouchMove(dx, -dy);
                }}
                onTouchEnd={() => { joyActive.current = false; setJoyPos({ x: 0, y: 0 }); gameRef.current?.setTouchMove(0, 0); }}>
                <div className="absolute left-1/2 top-1/2 h-14 w-14 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/25 backdrop-blur-md"
                  style={{ transform: `translate(calc(-50% + ${joyPos.x * 32}px), calc(-50% + ${joyPos.y * 32}px))` }} />
              </div>
              <div className="absolute bottom-28 right-4 z-10 flex gap-2">
                <button className="flex h-16 w-16 items-center justify-center rounded-full border border-white/20 bg-white/10 text-xs font-black backdrop-blur-md active:bg-white/30"
                  onTouchStart={(e) => { e.preventDefault(); doJump(); }}>ПРЫГ</button>
                <button className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-pink-300/50 bg-pink-500/30 text-sm font-black backdrop-blur-md active:bg-pink-500/60"
                  onTouchStart={(e) => { e.preventDefault(); gameRef.current?.setTouchFire(true); }}
                  onTouchEnd={() => gameRef.current?.setTouchFire(false)}>ОГОНЬ</button>
              </div>
            </>
          )}
        </>
      )}

      {/* ================= МЕНЮ ================= */}
      {phase === 'menu' && (
        <div className="absolute inset-0 overflow-y-auto" style={{ background: 'radial-gradient(1200px 600px at 50% -10%, #3b1d5e 0%, #0b1026 55%, #05070f 100%)' }}>
          {/* звёзды css */}
          <div className="pointer-events-none absolute inset-0 opacity-60" style={{ backgroundImage: 'radial-gradient(1.5px 1.5px at 20% 30%, #fff 100%, transparent 0), radial-gradient(1px 1px at 70% 15%, #fff 100%, transparent 0), radial-gradient(1.5px 1.5px at 85% 40%, #ffe9a8 100%, transparent 0), radial-gradient(1px 1px at 40% 10%, #fff 100%, transparent 0), radial-gradient(2px 2px at 55% 25%, #fbbf24 100%, transparent 0), radial-gradient(1px 1px at 10% 60%, #fff 100%, transparent 0), radial-gradient(1px 1px at 90% 70%, #fff 100%, transparent 0)' }} />
          <div className="relative mx-auto flex min-h-full w-full max-w-4xl flex-col items-center px-4 py-8 sm:py-12">
            <div className="flex items-center gap-2 rounded-full border border-amber-300/30 bg-amber-400/10 px-4 py-1.5 text-xs font-black tracking-widest text-amber-200">
              <Sparkles className="h-3.5 w-3.5" /> ПСКОВГУ • ПАРОДИЙНЫЙ FPS • 18+ ТРЭШ
            </div>
            <h1 className="mt-4 text-center text-5xl font-black leading-[0.95] tracking-tight sm:text-7xl">
              <span className="bg-gradient-to-b from-amber-200 via-amber-400 to-orange-600 bg-clip-text text-transparent drop-shadow-[0_4px_24px_rgba(251,191,36,0.35)]">ПСКОВГУ:</span><br />
              <span className="bg-gradient-to-b from-white via-pink-200 to-pink-500 bg-clip-text text-transparent">ПОБЕГ ЗА</span><br />
              <span className="bg-gradient-to-b from-lime-200 via-emerald-400 to-emerald-700 bg-clip-text text-transparent">ДИПЛОМОМ 🎓</span>
            </h1>
            <p className="mt-4 max-w-2xl text-center text-sm font-medium leading-relaxed text-white/70 sm:text-base">
              Ты — студент 5 курса. До диплома осталось <b className="text-amber-300">30 зачётов</b>, а преподы объявили на тебя охоту.
              К счастью, у тебя есть легендарное оружие — <b className="text-pink-300">ХУЕмёт-3000 «Стояк»</b> с бесконечными зарядами харизмы.
              Отстреливайся, собирай шпоры и энергетики, завали Декана — и забери свой диплом!
            </p>

            <div className="mt-6 grid w-full gap-3 sm:grid-cols-3">
              <div className="rounded-2xl border border-pink-300/25 bg-gradient-to-b from-pink-500/15 to-transparent p-4">
                <div className="flex items-center gap-2 text-sm font-black text-pink-200"><Crosshair className="h-4 w-4" /> ТВОЯ ПУШКА</div>
                <div className="mt-2 text-4xl">🍆🔫</div>
                <div className="mt-1 text-sm font-black">ХУЕмёт-3000 «Стояк»</div>
                <div className="text-xs text-white/60">Стреляет сгустками чистой уверенности. Перегревается — давай остыть!</div>
              </div>
              <div className="rounded-2xl border border-amber-300/25 bg-gradient-to-b from-amber-500/15 to-transparent p-4">
                <div className="flex items-center gap-2 text-sm font-black text-amber-200"><GraduationCap className="h-4 w-4" /> ЦЕЛЬ</div>
                <div className="mt-2 text-4xl">🎓</div>
                <div className="mt-1 text-sm font-black">30 зачётов = диплом</div>
                <div className="text-xs text-white/60">Каждый отчисленный препод — +1 зачёт в твою зачётку.</div>
              </div>
              <div className="rounded-2xl border border-red-300/25 bg-gradient-to-b from-red-500/15 to-transparent p-4">
                <div className="flex items-center gap-2 text-sm font-black text-red-200"><Skull className="h-4 w-4" /> ВРАГИ</div>
                <div className="mt-2 text-2xl">👨‍🏫👩‍🏫💂‍♂️👑</div>
                <div className="mt-1 text-sm font-black">Ассистенты → Декан</div>
                <div className="text-xs text-white/60">Каждая 3-я волна — босс. Физрук быстрый, профессор жирный.</div>
              </div>
            </div>

            <button onClick={handleStart} className="group mt-7 flex items-center gap-3 rounded-2xl bg-gradient-to-r from-amber-400 via-orange-500 to-pink-500 px-10 py-4 text-xl font-black tracking-wide text-black shadow-[0_10px_50px_rgba(251,146,60,0.45)] transition-transform hover:scale-105 active:scale-95">
              <Play className="h-6 w-6 transition-transform group-hover:translate-x-1" fill="currentColor" /> ИДТИ НА СЕССИЮ
            </button>
            <div className="mt-2 text-xs font-bold text-white/40">нажми — браузер попросит захват мыши, это нормально</div>

            <div className="mt-6 grid w-full gap-3 sm:grid-cols-2">
              <div className="rounded-2xl border border-white/10 bg-black/40 p-4 backdrop-blur-md">
                <div className="flex items-center gap-2 text-sm font-black"><Keyboard className="h-4 w-4 text-sky-300" /> УПРАВЛЕНИЕ</div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs font-bold">
                  {[['WASD', 'бегать'], ['МЫШЬ', 'осмотр'], ['ЛКМ', 'ОГОНЬ 🍆'], ['SHIFT', 'спринт'], ['SPACE', 'прыжок'], ['ESC', 'пауза']].map(([k, v]) => (
                    <div key={k} className="flex items-center gap-2 rounded-lg bg-white/5 px-2.5 py-2">
                      <span className="rounded-md bg-white/10 px-1.5 py-0.5 font-mono text-[11px] text-amber-200">{k}</span>
                      <span className="text-white/70">{v}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-2 flex items-center gap-1.5 text-[11px] text-white/50"><MousePointer2 className="h-3 w-3" /> На телефоне: левый стик — движение, правый — обзор, кнопка ОГОНЬ</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-black/40 p-4 backdrop-blur-md">
                <div className="flex items-center gap-2 text-sm font-black"><Award className="h-4 w-4 text-emerald-300" /> ЛУТ НА КАРТЕ</div>
                <div className="mt-3 space-y-2 text-xs font-bold">
                  <div className="flex items-center gap-2 rounded-lg bg-emerald-400/10 px-2.5 py-2"><Coffee className="h-4 w-4 text-emerald-300" /> Энергетик <span className="text-white/50">— +40 HP</span></div>
                  <div className="flex items-center gap-2 rounded-lg bg-yellow-400/10 px-2.5 py-2"><Zap className="h-4 w-4 text-yellow-300" /> Шпора <span className="text-white/50">— rapid-fire 10 сек</span></div>
                  <div className="flex items-center gap-2 rounded-lg bg-blue-400/10 px-2.5 py-2"><Briefcase className="h-4 w-4 text-blue-300" /> Взятка <span className="text-white/50">— щит 10 сек</span></div>
                </div>
                {hud.best > 0 && <div className="mt-3 flex items-center gap-1.5 text-xs font-black text-amber-300"><Trophy className="h-3.5 w-3.5" /> Рекорд: {hud.best} очков</div>}
              </div>
            </div>

            <div className="mt-5 max-w-2xl text-center text-[11px] leading-relaxed text-white/35">
              ⚠️ Пародия и трэш-юмор. Все преподы вымышлены, ни один реальный преподаватель ПсковГУ не пострадал.
              Оружие — мультяшный бластер, всё максимально целомудренно и смешно. Сделано студентом, который очень хочет диплом.
            </div>
          </div>
        </div>
      )}

      {/* ================= ПАУЗА ================= */}
      {phase === 'paused' && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-3xl border border-white/10 bg-[#121832] p-6 text-center shadow-2xl">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-400/15"><Pause className="h-7 w-7 text-amber-300" /></div>
            <h2 className="mt-3 text-2xl font-black">ПЕРЕМЕНКА ☕</h2>
            <p className="mt-1 text-sm text-white/60">Игра на паузе. Преподы тоже отдыхают... наверное.</p>
            <div className="mt-4 grid gap-2">
              <button onClick={handleResume} className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-lime-400 px-4 py-3 font-black text-black hover:brightness-110"><Play className="h-5 w-5" fill="currentColor" /> ВЕРНУТЬСЯ НА ПАРУ</button>
              <button onClick={handleRestart} className="flex items-center justify-center gap-2 rounded-xl bg-white/10 px-4 py-3 font-black hover:bg-white/15"><RotateCcw className="h-4 w-4" /> Начать заново</button>
            </div>
            <div className="mt-3 text-xs text-white/40">Клик вернёт захват мыши</div>
          </div>
        </div>
      )}

      {/* ================= СМЕРТЬ ================= */}
      {phase === 'dead' && (
        <div className="absolute inset-0 overflow-y-auto bg-gradient-to-b from-red-950/95 via-[#0b1026]/95 to-black/95 p-4 backdrop-blur-sm">
          <div className="mx-auto flex min-h-full w-full max-w-md flex-col items-center justify-center text-center">
            <div className="text-7xl">💀</div>
            <h2 className="mt-2 text-5xl font-black tracking-tight text-red-500 drop-shadow-[0_0_30px_rgba(239,68,68,0.5)]">ОТЧИСЛЕН</h2>
            <p className="mt-2 text-sm font-bold text-white/70">Деканат подписал приказ... Но настоящий студент не сдаётся!</p>
            <div className="mt-2 rounded-full border border-red-400/30 bg-red-500/10 px-4 py-1 text-xs font-black text-red-300">«Ну что, допрыгался со своим... бластером?» — Декан Иваныч</div>
            <div className="mt-5 grid w-full grid-cols-2 gap-2">
              {[
                ['Фрагов', endData.kills], ['Очков', endData.score],
                ['Волна', endData.wave], ['Время', fmtTime(endData.time)],
              ].map(([k, v]) => (
                <div key={k as string} className="rounded-2xl border border-white/10 bg-white/5 p-3">
                  <div className="text-2xl font-black">{v}</div>
                  <div className="text-xs font-bold text-white/50">{k}</div>
                </div>
              ))}
            </div>
            <div className="mt-3 w-full rounded-2xl border border-amber-300/20 bg-amber-400/5 p-3 text-sm">
              <span className="font-black text-amber-300">До диплома не хватило {Math.max(0, 30 - endData.kills)} зачётов.</span>
              <span className="text-white/60"> Мама расстроится, но мы верим в пересдачу!</span>
            </div>
            <button onClick={handleRestart} className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-pink-500 px-6 py-4 text-lg font-black text-black hover:brightness-110 active:scale-95">
              <RotateCcw className="h-5 w-5" /> НА ПЕРЕСДАЧУ!
            </button>
          </div>
        </div>
      )}

      {/* ================= ПОБЕДА ================= */}
      {phase === 'victory' && (
        <div className="absolute inset-0 overflow-y-auto bg-gradient-to-b from-amber-950/95 via-[#0b1026]/95 to-black/95 p-4 backdrop-blur-sm">
          {/* конфетти */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden">
            {Array.from({ length: 40 }).map((_, i) => (
              <div key={i} className="absolute animate-[fall_3s_linear_infinite]" style={{
                left: `${(i * 37) % 100}%`, top: '-20px', animationDelay: `${(i % 10) * 0.3}s`,
                width: 8, height: 12, background: ['#fbbf24', '#4ade80', '#ff7aa2', '#60a5fa', '#fff'][i % 5],
                transform: `rotate(${(i * 47) % 360}deg)`, borderRadius: 2,
              }} />
            ))}
          </div>
          <div className="relative mx-auto flex min-h-full w-full max-w-lg flex-col items-center justify-center text-center">
            <div className="flex items-center gap-2 rounded-full border border-amber-300/40 bg-amber-400/15 px-4 py-1.5 text-xs font-black text-amber-200"><Sparkles className="h-3.5 w-3.5" /> СЕССИЯ ЗАКРЫТА НА ОТЛИЧНО</div>
            <h2 className="mt-3 bg-gradient-to-b from-amber-200 via-yellow-400 to-orange-600 bg-clip-text text-5xl font-black text-transparent sm:text-6xl">ДИПЛОМ<br />ТВОЙ! 🎓</h2>
            {/* диплом */}
            <div className="mt-5 w-full rotate-[-1.5deg] rounded-xl border-8 border-double border-amber-600 bg-[#fdf6e3] p-6 text-[#1c1917] shadow-[0_20px_80px_rgba(251,191,36,0.35)]">
              <div className="text-[11px] font-black tracking-[0.3em] text-amber-700">ПСКОВСКИЙ ГОСУДАРСТВЕННЫЙ УНИВЕРСИТЕТ</div>
              <div className="mt-1 text-3xl font-black">ДИПЛОМ</div>
              <div className="text-xs font-bold text-stone-500">о высшем образовании с отличием и отвагой</div>
              <div className="mx-auto my-3 h-px w-3/4 bg-amber-600/40" />
              <div className="text-sm">Настоящим удостоверяется, что</div>
              <div className="text-xl font-black">ЛЕГЕНДАРНЫЙ СТУДЕНТ</div>
              <div className="text-sm">отчислил <b>{endData.kills} преподов</b>, пережил <b>{endData.wave} волн</b><br />и доказал мощь ХУЕмёта-3000</div>
              <div className="mt-3 flex items-end justify-between">
                <div className="text-left text-[11px] text-stone-500">Ректор<br /><span className="font-black text-stone-800">Повержен ✓</span></div>
                <div className="text-4xl">🎓</div>
                <div className="text-right text-[11px] text-stone-500">Декан<br /><span className="font-black text-stone-800">Отчислен ✓</span></div>
              </div>
            </div>
            <div className="mt-4 grid w-full grid-cols-4 gap-2">
              {[
                ['Фраги', endData.kills], ['Очки', endData.score],
                ['Волны', endData.wave], ['Время', fmtTime(endData.time)],
              ].map(([k, v]) => (
                <div key={k as string} className="rounded-2xl border border-white/10 bg-white/5 p-2.5">
                  <div className="text-lg font-black text-amber-200">{v}</div>
                  <div className="text-[11px] font-bold text-white/50">{k}</div>
                </div>
              ))}
            </div>
            <button onClick={handleRestart} className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 via-orange-500 to-pink-500 px-6 py-4 text-lg font-black text-black hover:brightness-110 active:scale-95">
              <RotateCcw className="h-5 w-5" /> ЕЩЁ РАЗОК (МАГИСТРАТУРА) <ChevronRight className="h-5 w-5" />
            </button>
            <div className="mt-2 flex items-center gap-1.5 text-xs text-white/40"><AlertTriangle className="h-3 w-3" /> Магистратура: те же преподы, но злее. Шутка. Или нет.</div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes feedIn { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: none; } }
        @keyframes fall { to { transform: translateY(110vh) rotate(720deg); } }
      `}</style>
    </div>
  );
}
