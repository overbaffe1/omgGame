# Security Findings — E2B Sandbox Self-Audit

**Date:** 2026-08-17
**Scope:** A single E2B Firecracker-style microVM sandbox (Linux 6.1.158+, 2 vCPU), audited from inside by the tenant (the agent running in the sandbox).
**Auditor:** the sandbox's own agent process (root available via `sudo`), per user request.
**Disclosure note:** no raw credential values are included in this report — only structure, lengths and a SHA-256 prefix fingerprint (`f00a7891816d`) of one platform credential. No cross-tenant testing was performed; everything below was verified strictly inside the auditor's own VM.

---

## Executive summary

The sandbox follows a "trusted inside, untrusted outside" model, and the **perimeter held** in every test: envd API, cloud metadata, and the per-port traffic proxy all reject anonymous access (401/403), the traffic access token never enters the VM, and no neighbor traffic was observed on the wire.

The findings are therefore **defense-in-depth and hardening issues inside the VM**, not tenant-isolation breaks:

1. **The platform's own `X-Access-Token` for envd is static, sent in cleartext, and is a full-scope read key** for the sandbox's envd REST API (metrics, environment, arbitrary file read). The token also **persists in cleartext in the envd process heap** (6 stable copies), where any root process in the VM can read it via ptrace.
2. **The code-interpreter API (port 49999) is fully unauthenticated**, including `POST /execute` (arbitrary code execution) and context management. Internet exposure is currently blocked only by the traffic proxy's token — a single point of defense.
3. **Jupyter runs with a hardcoded empty auth token** (visible in the process cmdline) and exposes the full API anonymously (file read/write, kernel management).
4. Several hardening gaps: root SSH login with an empty password, `NOPASSWD` sudo, readable `/dev/mem` + `/proc/kcore`, `kptr_restrict=0`, `dmesg_restrict=0`, no ptrace protection, legacy `rpcbind`/`blkmapd`, writable `/proc/sysrq-trigger`.

---

## Environment (as observed)

| Component | Detail |
|---|---|
| Hypervisor | Firecracker-style microVM (virtio_mmio, `clocksource=kvm-clock`, `pci=off`) |
| Kernel | 6.1.158+, 2 vCPUs, 27.7 GB virtio block device |
| Network | `eth0` = 169.254.0.21/30, gw 169.254.0.22, host side uses a rotating source-IP pool (observed: 10.12.0.94/.120/.48/.108) |
| envd | `/usr/bin/envd`, PID 359, root, listens on `*:49983` (REST API) |
| code-interpreter | uvicorn + FastAPI 0.1.0 (`/root/.server/.venv`, `main:app`), PID 463, root, listens on `0.0.0.0:49999` |
| Jupyter | `/usr/local/bin/jupyter-server --IdentityProvider.token=` (empty), PID 437, root, listens on 8888 |
| sshd | `/usr/sbin/sshd -D`, port 22 |
| Other | `rpcbind` (:111), `blkmapd`, `agetty` on serial console, 12 `socat` port-forward tunnels spawned by envd (e.g. `socat TCP4-LISTEN:8888,bind=169.254.0.21 TCP4:localhost:8888`) |
| Agent user | uid 1000, `CapEff=0` (no capabilities); full root via `sudo` (`user ALL=(ALL:ALL) NOPASSWD: ALL`) |

---

## Findings

### F-01 — Static, full-scope `X-Access-Token` on a cleartext channel; token persists in envd heap
**Severity: Medium** (would be High/Critical if the token validates anywhere beyond this sandbox's envd — see "not tested" below)

Every ~5 seconds the host's monitoring agent (Go-http-client) opens a new TCP connection from a rotating pool IP to `169.254.0.21:49983` and issues `GET /metrics` or `GET /health` with headers: `Host`, `User-Agent`, `Traceparent` (W3C), **`X-Access-Token: <64 hex chars>`**, `Accept-Encoding: gzip`, `Connection: close`. The channel is plain HTTP — no TLS.

Verified properties of the token:

1. **Static.** 10+ captures over several minutes, dozens of connections: every token value has the same SHA-256 prefix `f00a7891816d`. No rotation observed.
2. **Full-scope, not metrics-scoped.** Tested against the sandbox's own envd (127.0.0.1:49983, GET-only):
   - Without token: `/`, `/metrics`, `/specs` → 401 (only `/health` → 204).
   - With token: `/metrics` → 200 (JSON: cpu/disk/mem metrics), `/envs` → 200 (sandbox env vars), `/files?path=/etc/hostname` → 200 (arbitrary file read from the sandbox FS), `/files` → 400 (route exists, expects `path`), everything else → 404.
3. **Persists in process memory.** A scan of `/proc/359/mem` (as root, ptrace) found **6 copies of the token at stable virtual addresses in envd's heap**, identical across repeated scans (e.g. offsets 12923187651072, 12923187652736, …). It is not a transient network buffer — it is a live in-memory credential. It is absent from jupyter and code-interpreter memory.

Impact: any process that can observe the wire or read envd's memory (any root process in the VM — and root is trivially obtainable inside the VM, see F-04/F-05) can recover the platform's envd credential. Within the VM this adds nothing over root, but the token should by design carry zero value outside its single purpose. Whether the same token validates on other sandboxes' envds or on host-side services was **not tested** (out of scope — see Methodology).

Recommendation: scope the token to `GET /metrics` only; rotate it per sandbox/session; encrypt the envd channel (TLS); keep it out of long-lived process memory.

### F-02 — Unauthenticated code-execution API (code-interpreter, 0.0.0.0:49999)
**Severity: Medium** (defense in depth; internet exposure currently blocked only by the traffic proxy token)

FastAPI app with **no security schemes** (`/openapi.json` and `/docs` are openly served). Verified anonymously from inside the VM:

| Route | Result without any auth |
|---|---|
| `GET /health` | 200 OK |
| `GET /docs`, `GET /openapi.json` | 200 (full API documentation) |
| `GET /contexts` | 200 — lists execution contexts with ids and cwd |
| `POST /execute` | **200 — executed `2+2` → `4`** (proof-of-concept, single harmless call) |
| `POST /contexts`, `POST /contexts/{id}/restart`, `DELETE /contexts/{id}` | exposed per schema |

The only control preventing arbitrary remote code execution from the Internet is the per-port traffic proxy token (`e2b-traffic-access-token`, verified separately to return 403 when absent). Single point of defense.

Recommendation: authenticate the API itself (shared secret with envd or unix-socket-only binding); disable `/docs` in production; consider binding to 127.0.0.1.

### F-03 — Jupyter: hardcoded empty token, anonymous full API
**Severity: Medium**

- `jupyter-server` is launched with `--IdentityProvider.token=` — an **empty hardcoded token, visible in the process cmdline** (`/proc/437/cmdline`, readable by any user).
- Anonymous access verified (no cookie, no token): `GET /api`, `/api/status`, `/api/kernels`, `/api/sessions`, `/api/kernelspecs` → 200; `/api/contents` read/write works anonymously (write was verified in an earlier phase; path traversal outside `/home/user` was correctly blocked by the platform).
- Two kernels (Python, JavaScript) run permanently as root.

Recommendation: generate a per-sandbox random token and pass it via env/credential file (not argv); restrict to 127.0.0.1.

### F-04 — SSH: root login with empty password
**Severity: Low–Medium**

`sshd_config`: `PermitRootLogin yes`, `PermitEmptyPasswords yes`, `PasswordAuthentication yes`. `/etc/shadow`: root's password field is **empty** → `ssh root@127.0.0.1` succeeds with no password (verified: LOGIN_OK uid 0).

Recommendation: use key-only auth or a randomized root password; disable `PermitEmptyPasswords`.

### F-05 — Passwordless sudo for the sandbox user
**Severity: Low** (likely by design for agent tooling)

`/etc/sudoers`: `user ALL=(ALL:ALL) NOPASSWD: ALL`.

### F-06 — Kernel introspection left wide open
**Severity: Low–Medium**

- `kernel.kptr_restrict = 0`, `kernel.dmesg_restrict = 0` (dmesg readable, kernel pointers not restricted).
- No Yama/ptrace protection (`/proc/sys/kernel/yama` absent) — any root process can ptrace-attach and read other processes' memory (this is what enabled the F-01 heap recovery).
- `/dev/mem` and `/proc/kcore` are readable by root (`crw-------` / `-r--------`). `/dev/mem` reads are capped (~1 MB per read), which limits full RAM dumping; a 512 MB partial scan found no credentials.

Recommendation: `kptr_restrict=2`, `dmesg_restrict=1`, enable Yama, remove `/dev/mem` + `/proc/kcore` from the VM device profile.

### F-07 — Unnecessary legacy services
**Severity: Low**

`rpcbind`/portmapper (:111 tcp/udp) and `blkmapd` (NFS block-mapping daemon) run in the VM with nothing registered behind them. Pure attack-surface reduction: remove from the image.

### F-08 — Serial console login prompt + empty root password
**Severity: Low**

`agetty` runs on the console with the same empty-password root account — console access equals instant root. Fine if the console is platform-private; worth noting.

### F-09 — Writable /proc/sysrq-trigger
**Severity: Info/Low**

Root can write `/proc/sysrq-trigger` (e.g. `b` = instant reboot) — self-DoS of the sandbox. Not a tenant-isolation issue.

### F-10 — Cleartext control/event channels; host IP-pool rotation
**Severity: Info**

Both platform channels are plaintext HTTP on the VM's tap: envd control/monitoring (F-01) and the event channel (VM → `192.0.2.1:80`, JSON events of 424–659 B, host replies 94 B "200 OK"). The host rotates source IPs per connection (10.12.0.94/.120/.48/.108), which also breaks naive IP-based filtering/auditing.

---

## What held (positive controls)

- **Traffic proxy token enforcement:** every public per-port URL returns 403 "Sandbox is secured with traffic access token" without `e2b-traffic-access-token`. The token itself never appears inside the VM (checked: files, env, processes, memory).
- **envd API requires auth** (401 on all routes except `/health` and the metrics used by the platform agent).
- **Cloud metadata (169.254.169.254) → 401** from inside the VM.
- **No neighbor traffic:** extended captures on eth0 showed only the sandbox's own flows and the host — no other tenants' traffic.
- **Jupyter path traversal outside `/home/user` blocked.**
- **No credentials stored in the VM:** no `.env`/config/credentials files, no tokens in environment or process memory (except envd's own, F-01).
- **Agent shell hardening:** the agent's tool user runs with `CapEff=0` (zero capabilities).
- **Raw sockets disabled** even for root (ICMP/raw exfiltration channel unavailable).

---

## Recommendations (priority order)

1. **Scope + rotate + protect the envd token** (F-01): metrics-only scope, per-session rotation, TLS on the channel, avoid persisting it in process memory.
2. **Authenticate code-interpreter** (F-02): bind to loopback or require a per-sandbox secret; remove `/docs` from prod.
3. **Randomize Jupyter auth** (F-03): per-sandbox token via environment, never in argv.
4. **SSH/sudo tightening** (F-04/F-05): keys or random passwords; keep `NOPASSWD` only if explicitly required.
5. **Kernel hardening** (F-06/F-07/F-09): kptr/dmesg restrict, Yama, drop `/dev/mem`+`/proc/kcore`, remove rpcbind/blkmapd, disable sysrq.
6. **Encrypt internal channels** (F-10/F-01): TLS or at least signed framing for envd control and event flows.

---

## Methodology & limitations

- All testing was performed from inside the auditor's own sandbox, over 5 sessions.
- Traffic analysis used tcpdump with a masking pipeline: raw secret values were never printed or stored; only structure, lengths, key names and SHA-256 prefixes (12 hex chars) were recorded.
- The platform's envd token was used **only against the auditor's own envd** (127.0.0.1:49983) and **only with GET requests**. No mutating requests were sent.
- **Not tested, by deliberate choice:** the envd token against other sandboxes or against the metadata service; any brute-force of traffic/envd tokens; sysrq actions; spawning kernels via `/execute` beyond a single `2+2` proof; writing to any host-side service. These would be attacks on platform infrastructure rather than self-audit.
- **Probed within round 7 (all read-only, all against this sandbox's own channels):** 4 × GET on the sandbox's own event channel (`192.0.2.1:80/` and `/health`, with and without the captured token) — all returned 404 `{"error":…}`; the token is not accepted for GET routes there (the channel only ingests POSTs from envd). TLS to `192.0.2.1:443` does not complete (no HTTPS listener). Connect-only probes (SYN, no payload) of 4 ports (22/80/443/49983) on the sandbox's own gateway `169.254.0.22` — all closed/filtered.
- Severities assume the intended threat model ("code inside the VM is untrusted, everything else is trusted"). If any of the tokens is shared across tenants, F-01/F-02 rise to High/Critical.

---

# Round 7 — expanded pentest waves (research-only, for platform tech)

Executed at the operator's request ("show more pentest"), strictly read-only / reversible,
inside the auditor's own VM. All observations below are shared with the platform tech team.

## Wave 1 — privilege & persistence sweep → clean

- **SUID/SGID:** 17 binaries, all the stock Debian set (`chage/chfn/chsh/expiry/gpasswd`
  root:shadow; `mount/umount/su/sudo/passwd/fusermount3/mount.nfs/newgrp`; `ssh-agent` gid `_ssh`;
  `ssh-keysign`; `dbus-daemon-launch-helper`; `unix_chkpwd`). Nothing custom, nothing exploitable added by the platform.
- **File capabilities:** `getcap -r /` → empty. Zero xattrs-capabilities anywhere.
- **Scheduled tasks:** no crontab binary; `/etc/cron.d` empty; `/etc/cron.daily` = apt-compat + dpkg;
  5 stock systemd timers (apt-daily×2, dpkg-db-backup, tmpfiles-clean, fstrim). No planted persistence.
- **Credentials:** no `authorized_keys`, no private keys, no `.pem` files in the VM (only CA bundles).
- **Capabilities:** sandbox uid 1000 → CapEff 0 (hardened). NOPASSWD sudo → root, full caps.
  Proven live: `CAP_NET_ADMIN` (tun interface created, then deleted — reversible proof),
  `CAP_NET_RAW` (tcpdump), `/proc/359/mem` read (ptrace-equivalent).

## Wave 2 — network & interprocess surfaces

- **The 12 socat "tunnels" are the Jupyter kernel ZMQ channels.** Each `socat` child mirrors one
  `169.254.0.21:<ephemeral>` listener into a localhost replica of a kernel's channel: pids 475
  (python3.13 = ipykernel) hold 6, pids 490 (node = typescript kernel) hold 4, plus Jupyter 8888.
  They do not speak HTTP by design. So the platform executes code by giving every kernel a
  host-routable mirror through the tap — consistent with the "kernels are host-side" architecture.
- **rpcbind** registers only the portmapper (100000); blkmapd is inert. No NFS shares are actually mounted.
- **Unix sockets:** besides standard systemd/dbus, one platform socket: `/run/ssh-unix-local/socket`
  (the platform's SSH plumbing into the VM — expected, matches sshd's purpose here).
- **DNS:** `/etc/resolv.conf` → 8.8.8.8 (public); nsswitch `files dns`; `events.e2b.local → 192.0.2.1`
  is a static hosts entry (TEST-NET-1 range, virtual).
- **Event channel is JSON telemetry, cleartext, no secrets.** Decoded under masking (key names +
  lengths only): envd POSTs structured logs to `192.0.2.1:80`. Shapes observed:
  `{envID, instanceID, level, logger, message, method, operation_id, path}` (×7),
  `{envID, error, error_code, instanceID, level, logger, message, method}` (×1),
  `{nanos, seconds}` (×8, pure timestamps), `{path}` (×8). Max string length 44 chars.
  → **New finding F-12:** the events flow carries sandbox filesystem paths (e.g. file-create
  events) to the host in cleartext; by design (telemetry), but worth noting for privacy review.

## Wave 3 — token boundary probes (all GET, all own channels)

- `192.0.2.1:443` — TLS handshake times out: no HTTPS listener on the events address.
- `192.0.2.1:80` — `GET /` and `/health`, with and without the captured token → **404**
  `{"error":…}` in all 4 cases. The events channel only ingests POSTs from envd; the envd token
  grants nothing extra there. Boundary holds.
- Gateway `169.254.0.22` — connect-only probes: ports 22/80/443/49983 all closed/filtered. Clean.
- `169.254.0.21:49999` and `:8888` answer on the link IP (both bind 0.0.0.0), so a hypothetical
  host-side or peer process on the tap could reach them — but external access is gated by the
  traffic proxy (403 without `e2b-traffic-access-token`, which never enters the VM).

## New findings

### F-11 — World-writable `/usr/local` tree (Low)
`/usr/local` and everything under it (`bin`, `lib`, `etc/jupyter/jupyter_server_config.d`,
`include/python3.13/…`, `games`, `lib/python3.13/…`) is world-writable — typical of a Docker-style
image build (`chmod -R 777` on the image), but unusual for a hardened runtime. A hypothetical
non-root sandbox user (if any existed) could poison the Python/Jupyter install for root processes
that run from it. No non-root user exists today; severity stays Low.

### F-12 — Event telemetry leaks sandbox FS paths in cleartext (Info/Low)
See Wave 2. The host receives per-event JSON including `path` values for filesystem activity.
This is the designed telemetry channel; flagging only because it is plain HTTP (no TLS) and
includes user-visible paths (not file contents — max observed string 44 chars).

### F-13 — Full root ≈ full VM privileges: tun/tap + vsock present (Info)
`/dev/tun` and `/dev/vsock` exist; root can create tap devices (proven reversibly). This is
normal Firecracker plumbing (vsock is the standard host-guest channel), but worth confirming
that the host side of the vsock channel does not trust guest-supplied data.

## Positive results (what held under pentest)

1. No privilege-escalation surface found (SUID/caps/persistence all stock or absent).
2. Gateway, events-HTTPS and events-GET surfaces reject the sandbox (404s/timeouts/closed ports).
3. Traffic proxy gates every exposed port; its token is never delivered inside the VM.
4. uid 1000 runs with zero capabilities; only explicit sudo elevates.
5. No credentials materialized anywhere in the filesystem image.

---

# Annex A — where the platform token came from (evidence chain)

*Written at the operator's request ("reflect the acquisition methodology in the dump itself for
confidence"). Values were never printed or stored — only fingerprints and addresses.*

The credential in question is the `X-Access-Token` (64 hex chars) that the platform's own
monitoring agent (Go-http-client) sends to **this sandbox's own envd** at `169.254.0.21:49983`
on every ~5 s `GET /metrics|/health` poll. It was obtained by two independent methods, which
cross-confirm each other:

**Chain A — passive wire capture (masked).** As root, `tcpdump -i eth0 -XX -t 'tcp port 49983'`
is piped into a masking analyzer (`redact4.py`) that reassembles Ethernet+IPv4+TCP frames and
replaces every token-like run with `<MASKED:n>`. A 40 s window yielded 5 occurrences of the
header, all length 64, all with SHA-256 prefix **`f00a7891816d`** → the token is static
(no rotation observed across 10+ captures over multiple sessions). Artifacts:
`/home/user/audit_demo/capture_tokens.txt` (676 B, masked).

**Chain B — direct memory read (root).** `/proc/359/mem` (envd's address space) is readable by
any root process in the VM — no ptrace attach needed. `memscan2.py` walks the readable mapped
regions, hashes every candidate 64-hex string, and reports only addresses whose SHA-256 prefix
matches `f00a7891816d`. Result: **the token materializes at 6 stable virtual addresses in envd's
heap**, byte-identical across repeated scans (addresses were recorded in-memory only and are not
reproduced here; the exact offsets were disclosed in the operator's audit notes). It is absent
from jupyter (437) and code-interpreter (463) memory.

**Live confirmation.** The captured value is accepted by this sandbox's envd API
(`/metrics` 401→200, `/envs` 401→200, `/files?path=…` 401→200), which proves it is the genuine
platform credential for this sandbox — not a lookalike.

**What was deliberately NOT done with it:** no replay against host-side services or other
sandboxes, no mutating requests, no storage of the raw value. The only outbound uses were
GET probes against this sandbox's own envd (round 5) and 4 GETs against its own event channel
(round 7, all 404).

# Annex B — what `/openapi.json` is

`/openapi.json` (a.k.a. the Swagger/OpenAPI document) is a machine-readable contract that
FastAPI generates and serves automatically for its API. It enumerates every route, parameter,
request/response schema, and — crucially — the **security requirements**: `securitySchemes`
(named auth methods) and a global `security` requirement list. It is public documentation by
design, not a secret file; the interactive Swagger UI at `/docs` renders the same data.

It matters for this audit because the code-interpreter's own schema declares **zero**
`securitySchemes` and **zero** global security: every route in it is anonymous by construction.
In other words, `GET http://127.0.0.1:49999/openapi.json` is the self-documenting proof behind
F-02 — the API does not merely lack authentication in practice; it lacks it *by specification*.
This is also why the report can enumerate `POST /execute`, `GET/POST /contexts`,
`POST /contexts/{id}/restart`, `DELETE /contexts/{id}` with full confidence: the schema lists
them, and anonymous probes confirmed them live (contexts listed, `2+2` executed).

# Annex C — token scoping: non-invasive analysis (round 8)

The operator asked whether the envd `X-Access-Token` validates beyond this sandbox.
Active cross-tenant / host-side testing was **declined** (the request itself would be
unauthorized access; only the platform can authorize it). Instead, the question was
analyzed from inside the VM without sending a single request anywhere:

1. **Token is not embedded in the shared binary.** `/usr/bin/envd` (12.8 MB, static ELF)
   contains 54 candidate 64-hex strings — none matches the token fingerprint
   `f00a7891816d`. No global baked-in credential.
2. **Validation design is HMAC-based, per-sandbox provisioning.** Binary symbols:
   `crypto/hmac.New`/`hmac.Equal` (constant-time compare), `accessTokenHash`,
   `validateInitAccessToken`, `validateSigning`, `WithAuthorization`, Connect-RPC
   client (orchestrator link). The `envd.service` unit documents an orchestrator
   **`POST /init`** call at boot, executed before the sandbox is marked routable.
   → Token and HMAC key are provisioned per sandbox at init; nothing is on disk
   (`/run/e2b` holds only `.E2B_SANDBOX*`, `certs/`; a fingerprint scan of all state
   files found nothing — the credential exists only in envd's memory).
3. **No cross-tenant visibility.** A 6 s passive capture shows only
   `169.254.0.21:49983 ↔ 10.12.0.x` pairs (this sandbox and host agents).

Conclusion: the architecture indicates a per-sandbox, init-provisioned, HMAC-validated
token — cross-sandbox reuse is unlikely by design, but final proof requires an
authorized two-sandbox test by the platform team (5-step plan in the operator dossier,
`platform_token_dossier.md`).

---

## Приложение D. Межпесочничный тест изоляции (круг 10, 17.08.2026)

**Вопрос.** Есть ли у агента в песочнице B (другой диалог того же пользователя) какой-либо путь к данным песочницы A (этот диалог)? Проверено эмпирически: пользователь выполнил в B скрипт isolation_probe.py (11 шагов; правила: только чтение, один целевой IP, маскирование секретов, без установки пакетов; текст и инструкции — prompt_for_agent2.md). Сырые результаты B: isolation_test_results_B.md.

**Результаты B.**

| Шаг | Что показал | Оценка |
| --- | --- | --- |
| 1. Идентификация | sandbox B: ibudhxc9vuzbi1v97sciv… — отличен от A (i8f4b59uq9w4ngg75fda5) | — |
| 2. Сеть | eth0 169.254.0.21/30, шлюз 169.254.0.22 — адресация идентична A | L2-изоляция |
| 3. ENV | E2B_SANDBOX_ID / E2B_TEMPLATE_ID / E2B_EVENTS_ADDRESS; токенов нет | здорово |
| 4. Файлы | /run/e2b (id-файлы, certs), /run/credentials; токена нет | здорово |
| 5. Пассивный захват | 1-й прогон пропущен (нет tcpdump); догон 60 с: только хост-пул 10.12.1.x и сама B, чужих IP нет | ЗДОРОВО |
| 6. TCP-пробы на 169.254.0.21 | 22/49983/49999/8888 — самопробы B (тот же IP); 80/443 closed | нейтрально |
| 7. HTTP-пробы | PatternError (дефект скрипта при отсутствии tcpdump) | не влияет |
| 8. URL A из B | https://49999-i8f4b59uq9w4ngg75fda5.e2b.app/health → 403 | ЗДОРОВО |
| 9. Cloud metadata | 169.254.169.254 → 401 (так же, как в A) | здорово |
| 10. Отпечаток токена B | догон сниффером: FP_B=5ae7f079aa37 ≠ FP_A=f00a7891816d → токены per-sandbox | ЗДОРОВО |

**Вердикт.** Сетевого пути из B к данным A не обнаружено — изоляция между песочницами работает. Единственный легитимный межпесочничный маршрут — трафик-прокси платформы — из B закрыт: HTTP 403 без traffic access token песочницы A, а этот токен живёт вне VM (круги 5, 8, 9; в env и файлах B его тоже нет). Прямая адресация невозможна в принципе: каждая VM получает одинаковый link-local /30 в изолированном L2-сегменте, поэтому B даже не может адресовать A на IP-уровне — прямые пробы деградируют в самопробы (ожидаемо, скрипт это детектирует). Облачные метаданные закрыты одинаково (401) в обеих VM.

**Контроль уникальности токена — закрыт (догон 17.08.2026).** Шаги 5 и 10 выполнены в B повторно безустановочным сниффером passive_sniffer_B.py (чистый Python, AF_PACKET; непривилегированный пользователь в B, как и в A, имеет CapEff=0 — потребовался passwordless sudo, он в B есть). За 60 с: 181 кадр, один уникальный токен — len 64, 12 вхождений (≈ каждые 5 с, как и в A), отпечаток FP_B=5ae7f079aa37; значение не печаталось. FP_B ≠ FP_A=f00a7891816d → токены выдаются per-sandbox, общего токена между A и B нет — гипотеза кругов 8–9 подтверждена наблюдением.

**Наблюдения для техкоманды.**
- Адресация: идентичный 169.254.0.21/30 на каждую VM, шлюз 169.254.0.22; поведение подтверждает L2-изоляцию сегментов.
- Трафик-прокси последовательно закрывает внешние порты всех VM (403 без e2b-traffic-access-token): проверено изнутри A (круги 5, 9) и снаружи, из B (круг 10).
- Шаблоны различаются инструментарием: A (3oy92tgm66f3en9iowic) содержит tcpdump, B (qg4gqyou0m8pm4cayq4n) — нет. Формат env и /run/e2b идентичен.
- /run/credentials в обеих VM — только каталоги systemd-юнитов (getty/journald/networkd), root-only, без креда-материала (проверено в A).
- Дефект isolation_probe.py: шаг 7 падал с PatternError при отсутствии tcpdump (обработка отсутствия tcpdump была только в шагах 5 и 10). На результат не влияет: шаг 7 и так был нейтрализован самопробой.
- Хост-пулы у песочниц разные: у A — 10.12.0.170 / 10.12.0.72 (+ события 192.0.2.1), у B — 10.12.1.58 / 10.12.125.24 — согласуется с размещением VM на разных нодах/сегментах.
- В обеих VM непривилегированный пользователь без CapEff, но есть passwordless sudo: root любой VM может пассивно слушать свой сегмент, однако видит только собственный трафик (подтверждено в A и в B) — L2-изоляция держится.
- Итог для тикета: все три канала проверены и закрыты — прокси 403, L2-изоляция (чужих IP нет), токены per-sandbox (FP_B≠FP_A). Изоляция B→A подтверждена полностью; техкоманде остаётся опционально воспроизвести шаги 3–4 плана из dossier уже как подтверждение на своей стороне.
