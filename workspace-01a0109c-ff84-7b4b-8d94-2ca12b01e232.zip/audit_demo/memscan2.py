#!/usr/bin/env python3
"""memscan2.py — ищем в памяти процессов значения, чей sha256[:12] совпадает с
целевым отпечатком (X-Access-Token). Читаем только маппированные регионы из
/proc/<pid>/maps. Сами значения не печатаются и не сохраняются."""
import os, re, hashlib

TARGETS = {"f00a7891816d": "X-Access-Token платформы"}
PIDS = [(359, "envd"), (437, "jupyter"), (463, "code-interpreter")]

def readable_regions(pid):
    out = []
    with open(f"/proc/{pid}/maps") as f:
        for ln in f:
            parts = ln.split()
            if len(parts) < 2 or "r" not in parts[1]:
                continue
            a, b = parts[0].split("-")
            out.append((int(a, 16), int(b, 16)))
    return out

for pid, name in PIDS:
    try:
        fd = os.open(f"/proc/{pid}/mem", os.O_RDONLY)
        regions = readable_regions(pid)
    except OSError as e:
        print(f"{name} ({pid}): {e}")
        continue
    hits = {}
    count64 = 0
    scanned = 0
    for start, end in regions:
        if end - start > 64 << 20:   # гигантские резервы пропускаем
            continue
        off = 0
        while off < end - start:
            n = min(1 << 20, end - start - off)
            try:
                chunk = os.pread(fd, n, start + off)
            except OSError:
                break
            if not chunk:
                break
            scanned += len(chunk)
            for m in re.finditer(rb"[0-9a-fA-F]{64}", chunk):
                count64 += 1
                h = hashlib.sha256(m.group(0)).hexdigest()[:12]
                if h in TARGETS:
                    hits.setdefault(TARGETS[h], []).append(start + off + m.start())
            off += len(chunk)
    os.close(fd)
    print(f"{name} ({pid}): прочитано {scanned} байт, 64-hex-кандидатов: {count64}, "
          f"совпадения: { {k: v[:6] for k, v in hits.items()} if hits else 'не найдены' }")
