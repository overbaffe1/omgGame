#!/usr/bin/env python3
"""Дубль 3: контекстный анализ. Значения секретов ВСЕГДА маскируются,
наружу выходят только: имена JSON-ключей, контекст вокруг маскированных значений
(до 14 симв. до / 4 после), длины значений, структура HTTP если встретится."""
import re
import sys

raw = sys.stdin.buffer.read().decode("latin-1")

packets, cur = [], None
for ln in raw.splitlines():
    if ln.startswith("IP ") or ln.startswith("Ethernet ") or re.match(r"\d\d:\d\d:\d\d", ln):
        if cur is not None:
            packets.append(cur)
        cur = bytearray()
        continue
    m = re.match(r"^\s*0x[0-9a-fA-F]+:\s+([0-9a-fA-F]{2}(?:\s+[0-9a-fA-F]{2}){0,15})", ln)
    if m and cur is not None:
        for h in m.group(1).split():
            cur.append(int(h, 16))
if cur is not None:
    packets.append(cur)

diag = {"HTTP/": 0, "GET ": 0, "POST ": 0, "Authorization": 0, "Bearer": 0,
        "e2b_": 0, "{": 0, "sig": 0, "token": 0, "key": 0, "api": 0}
keys = {}
contexts = []
lens = []

RX_TOKEN = re.compile(r"[A-Za-z0-9+/_-]{40,}={0,2}")

def printable(s):
    return "".join(c if 32 <= ord(c) < 127 else "." for c in s)

def mask_and_collect(text):
    for k in ["HTTP/", "GET ", "POST ", "Authorization", "Bearer", "e2b_", "{", "sig", "token", "key", "api"]:
        diag[k] += text.lower().count(k.lower())
    for m in RX_TOKEN.finditer(text):
        s = m.start()
        lens.append(len(m.group(0)))
        ctx = printable(text[max(0, s - 14):s]) + "||" + printable(text[m.end():m.end() + 4])
        contexts.append(ctx)
    for m in re.finditer(r'"([A-Za-z0-9_\-\.]{1,40})"\s*:', text):
        keys[m.group(1)] = keys.get(m.group(1), 0) + 1
    return RX_TOKEN.sub("[REDACTED]", text)

reqs, resps = [], []
for p in packets:
    if not p:
        continue
    safe = mask_and_collect(p.decode("latin-1"))
    for ln in safe.splitlines():
        m = re.match(r"(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS|CONNECT)\s+(\S+)\s+(HTTP/\d\.\d)", ln)
        if m:
            reqs.append((m.group(1), m.group(2).split("?")[0][:50], m.group(3)))
        m = re.match(r"(HTTP/\d\.\d)\s+(\d{3})", ln)
        if m:
            resps.append((m.group(1), m.group(2)))

print("=== диагностика (счётчики) ===")
for k, v in diag.items():
    if v:
        print(f"   {k}: {v}")
print("=== HTTP-структура (если есть) ===")
print("   запросы:", reqs[:10] or "(нет)")
print("   ответы:", resps[:10] or "(нет)")
print("=== имена JSON-ключей протокола (частота) ===")
for k, v in sorted(keys.items(), key=lambda x: -x[1])[:35]:
    print(f"   {k}: {v}")
print("=== длины вырезанных значений ===")
print("   всего:", len(lens), " распределение:", {n: lens.count(n) for n in sorted(set(lens))})
print("=== контекст вокруг вырезанных значений (до 25 шт.) ===")
for c in contexts[:25]:
    print("   ...", c, "...")
print("=== всего маскировано:", len(contexts), "===")
