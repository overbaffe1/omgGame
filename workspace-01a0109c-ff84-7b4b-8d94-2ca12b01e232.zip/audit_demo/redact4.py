#!/usr/bin/env python3
"""Финальный форензик кадра. Разбирает TCP-потоки, ловит установку НОВЫХ
соединений и анализирует их первые пейлоады: фрейминг (hex только если байты
явно бинарные), длины и позиции маскированных значений, JSON-ность.
Сами значения секретов не печатаются никогда."""
import re
import sys
import collections

raw = sys.stdin.buffer.read().decode("latin-1")

packets = []
cur_hdr, cur = None, None
for ln in raw.splitlines():
    if ln.startswith("IP ") or ln.startswith("Ethernet "):
        if cur is not None:
            packets.append((cur_hdr, bytes(cur)))
        cur_hdr, cur = ln, bytearray()
        continue
    # tcpdump -XX печатает байты парами hex-символов (02fc = байты 02 и fc),
    # группы через ОДИН пробел; ASCII-колонка отделена ДВУМЯ пробелами.
    m = re.match(r"^\s*0x[0-9a-fA-F]+:\s+((?:[0-9a-fA-F]{2} ?){1,16})", ln)
    if m and cur is not None:
        cur.extend(bytes.fromhex(m.group(1).replace(" ", "")))
if cur is not None:
    packets.append((cur_hdr, bytes(cur)))

def tcp_data(fr):
    if len(fr) < 54 or fr[12:14] != b"\x08\x00":
        return b""
    ihl = (fr[14] & 0x0F) * 4
    tcp = 14 + ihl
    doff = ((fr[tcp + 12] >> 4) & 0x0F) * 4
    return fr[tcp + doff:]

stats = collections.Counter()
firsts = []          # первые пейлоады новых соединений (host -> vm)
token_info = []      # (len, rel_pos_in_packet)
payload_sizes = []   # размеры всех пейлоадов
conns = {}

for hdr, fr in packets:
    d = tcp_data(fr)
    src = re.search(r"IP ([\d.]+)\.(\d+) > ([\d.]+)\.(\d+)", hdr)
    fl = re.search(r"Flags \[([^\]]*)\]", hdr)
    if not src or not fl:
        continue
    s_ip, s_port, d_ip, d_port = src.group(1), int(src.group(2)), src.group(3), int(src.group(4))
    f = fl.group(1)
    host_to_vm = not s_ip.startswith("169.254.")
    key = s_port if host_to_vm else d_port
    if "S" in f and "S." not in f and "A" not in f:
        conns[key] = "new"
        stats["новых_соединений"] += 1
        stats[f"новое_от_{s_ip}"] += 1
    if d and conns.get(key) == "new" and host_to_vm:
        conns[key] = "seen"
        stats["первых_пейлоадов"] += 1
        firsts.append(d)
    if d:
        stats["пакетов_с_данными"] += 1
        stats["байт_данных"] += len(d)
        payload_sizes.append(len(d))
        for m in re.finditer(rb"[A-Za-z0-9+/_-]{40,}={0,2}", d):
            token_info.append((len(m.group(0)), round(m.start() / len(d), 2)))

print("=== статистика канала ===")
for k, v in sorted(stats.items()):
    print(f"   {k}: {v}")

print("=== гистограмма размеров пейлоадов (топ-12) ===")
if payload_sizes:
    for sz, n in collections.Counter(payload_sizes).most_common(12):
        print(f"   {sz}B: {n}")

print("=== первые пейлоады новых соединений ===\n   (host->vm: печатается только первая печатная строка = HTTP-запрос/структура;\n    vm->host и бинарь: печатается hex ТОЛЬКО если байты бинарные, иначе скрыто)")
for i, p in enumerate(firsts):
    nonpr = sum(1 for b in p if b < 32 or b > 126)
    frac = nonpr / max(1, len(p))
    head = p[:16]
    grpc = len(p) >= 5 and p[0] in (0, 1) and int.from_bytes(p[1:5], "big") == len(p) - 5
    runs = [len(r) for r in re.findall(rb"[ -~]{10,}", p)]
    first_line = ""
    if p[:4] in (b"GET ", b"POST", b"PUT ", b"HEAD", b"DELE", b"PATC", b"OPTI"):
        eol = p.find(b"\r\n")
        if eol > 0:
            line = p[:eol].decode("latin-1")
            line = line.split("?", 1)[0]  # query-параметры (могут быть токенами) не печатаем
            first_line = "first_line=" + line
    elif p[:5] == b"HTTP/":
        eol = p.find(b"\r\n")
        first_line = "status_line=" + p[:eol].decode("latin-1") if eol > 0 else ""
    if nonpr >= 8:
        head_desc = "hex: " + head.hex()
    else:
        head_desc = "<печатаемое — hex скрыт>"
    print(f"   №{i}: len={len(p)}, binary={frac:.0%}, grpc-фрейм={grpc}, "
          f"'{{'={p.count(b'{')}, '\"'={p.count(b'\"')}, "
          f"печатные-раны={runs[:8]}, {head_desc}, {first_line}")

print("=== маскированные значения в потоке данных ===")
print("   всего:", len(token_info))
print("   длины:", dict(collections.Counter(t for t, _ in token_info)))
print("   позиции в пакете (0=начало, 1=конец):", sorted(set(rp for _, rp in token_info))[:20])
