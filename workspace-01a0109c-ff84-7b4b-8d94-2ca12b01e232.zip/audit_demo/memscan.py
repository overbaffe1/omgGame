import re
import sys

pid = int(sys.argv[1])
with open(f"/proc/{pid}/maps") as f:
    maps = f.read().splitlines()

pat = re.compile(rb"[A-Za-z0-9_\-]{20,60}")
cand = {}
regions = 0
total = 0
for line in maps:
    m = re.match(r"([0-9a-f]+)-([0-9a-f]+)\s+(....)\s+", line)
    if not m:
        continue
    start, end, perms = int(m.group(1), 16), int(m.group(2), 16), m.group(3)
    if perms[0] != "r" or "s" in perms:
        continue
    size = end - start
    if size > 20 * 1024 * 1024 or size < 1:
        continue
    if total > 400 * 1024 * 1024:
        break
    regions += 1
    total += size
    try:
        with open(f"/proc/{pid}/mem", "rb") as f:
            f.seek(start)
            data = f.read(size)
    except OSError:
        continue
    for s in pat.findall(data):
        if s in cand:
            cand[s] += 1
        else:
            cand[s] = 1

print(f"pid={pid} regions={regions} bytes_read={total}")
top = sorted(cand.items(), key=lambda x: -x[1] * len(x[0]))[:18]
for s, c in top:
    mask = s[:4].decode(errors="replace") + "\u2026" + s[-2:].decode(errors="replace")
    print(f"len={len(s):3d} count={c:3d} masked={mask}")
print("(полные значения намеренно не показываю)")
