#!/bin/bash
# Дубль 5: 75с. redact4.py с гистограммой размеров. Маска в памяти, диск чист.
sudo -n timeout 75 tcpdump -i eth0 -nn -t -XX 'tcp port 49983' 2>/dev/null \
  | python3 /home/user/audit_demo/redact4.py > /home/user/audit_demo/capture_envd.txt &
sudo -n timeout 75 tcpdump -i eth0 -nn -t -XX 'host 192.0.2.1 and tcp port 80' 2>/dev/null \
  | python3 /home/user/audit_demo/redact4.py > /home/user/audit_demo/capture_events.txt &
wait
echo CAPTURE_DONE
