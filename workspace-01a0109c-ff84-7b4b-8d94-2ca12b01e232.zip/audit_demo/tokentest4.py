#!/usr/bin/env python3
"""tokentest4.py — те же 2 GET (/ и /health) на events-канал envd 192.0.2.1:80
(plain HTTP, как в захвате). Токен из живого захвата, наружу не печатается,
не сохраняется (только sha256[:12]+len). Только чтение, только GET,
только собственный events-канал этой же песочницы."""
import re, sys, json, http.client, hashlib

raw = sys.stdin.buffer.read().decode("latin-1")
frames, cur = [], None
for ln in raw.splitlines():
    if ln.startswith("IP "):
        if cur is not None:
            frames.append(cur)
        cur = [ln, bytearray()]
        continue
    m = re.match(r"^\s*0x[0-9a-fA-F]+:\s+((?:[0-9a-fA-F]{2} ?){1,16})", ln)
    if m and cur is not None:
        cur[1].extend(bytes.fromhex(m.group(1).replace(" ", "")))
if cur is not None:
    frames.append(cur)

def tcp_data(fr):
    if len(fr) < 54 or fr[12:14] != b"\x08\x00":
        return b""
    ihl = (fr[14] & 0x0F) * 4
    tcp = 14 + ihl
    doff = ((fr[tcp + 12] >> 4) & 0x0F) * 4
    return fr[tcp + doff:]

token = None
for hdr, fr in frames:
    d = tcp_data(fr)
    if not d:
        continue
    s = re.search(r"IP ([\d.]+)\.", hdr)
    if s and s.group(1).startswith("169.254."):
        continue
    m = re.search(rb"X-Access-Token:\s*([A-Fa-f0-9]{64})", d)
    if m:
        token = m.group(1)
        break

if not token:
    print("RESULT: токен в окне захвата не найден — пробовать нечего")
    sys.exit(0)

h12 = hashlib.sha256(token).hexdigest()[:12]
print(f"RESULT: токен пойман, len={len(token)}, sha256[:12]={h12}")

def mask(s):
    return re.sub(r"[A-Za-z0-9+/_\-.@]{20,}",
                  lambda m: f"<MASKED:{len(m.group(0))}>", s)

def describe(body, ctype):
    if not body:
        return "пусто"
    if "json" in (ctype or ""):
        try:
            obj = json.loads(body)
        except Exception:
            return "JSON(битый): " + mask(body[:120].decode("latin-1"))
        if isinstance(obj, dict):
            return "JSON-ключи: " + ",".join(sorted(obj.keys())[:15])
        return f"JSON {type(obj).__name__}"
    return "text: " + mask(body[:100].decode("latin-1"))

print("=== events.e2b.local (192.0.2.1:80) — GET, только / и /health ===")
for mode, hdrs in [("с токеном", {"X-Access-Token": token.decode("latin-1")}),
                   ("без токена", {})]:
    for r in ["/", "/health"]:
        try:
            c = http.client.HTTPConnection("192.0.2.1", 80, timeout=4)
            c.request("GET", r, headers=dict(hdrs, Connection="close"))
            resp = c.getresponse()
            body = resp.read(1024)
            print(f"  [{mode}] {r:8} -> {resp.status}  ct={resp.getheader('Content-Type') or '-'}  "
                  f"len={len(body)}  {describe(body, resp.getheader('Content-Type'))}")
            c.close()
        except Exception as e:
            print(f"  [{mode}] {r:8} -> ОШИБКА {type(e).__name__}: {str(e)[:80]}")
