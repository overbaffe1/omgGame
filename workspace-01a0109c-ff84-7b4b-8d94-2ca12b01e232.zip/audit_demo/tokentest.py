#!/usr/bin/env python3
"""tokentest.py — пробуем X-Access-Token платформы СТРОГО против собственного
envd (127.0.0.1:49983), только GET. Токен извлекается из живого захвата,
наружу не печатается и не сохраняется (только sha256[:12]). Тела ответов
маскируются: для JSON — только имена ключей, для текста — длинные
alphanumeric-последовательности заменяются на <MASKED:n>."""
import re, sys, json, http.client, hashlib, time

raw = sys.stdin.buffer.read().decode("latin-1")
frames, cur = [], None
for ln in raw.splitlines():
    if ln.startswith("IP "):
        if cur is not None:
            frames.append(cur)
        cur = [ln, bytearray()]
        continue
    m = re.match(r"^\s*0x[0-9a-fA-F]+:\s+((?:[0-9a-fA-F]{2} ?){1,16})", ln)
    if m and cur is not None:
        cur[1].extend(bytes.fromhex(m.group(1).replace(" ", "")))
if cur is not None:
    frames.append(cur)

def tcp_data(fr):
    if len(fr) < 54 or fr[12:14] != b"\x08\x00":
        return b""
    ihl = (fr[14] & 0x0F) * 4
    tcp = 14 + ihl
    doff = ((fr[tcp + 12] >> 4) & 0x0F) * 4
    return fr[tcp + doff:]

token = None
for hdr, fr in frames:
    d = tcp_data(fr)
    if not d:
        continue
    s = re.search(r"IP ([\d.]+)\.", hdr)
    if s and s.group(1).startswith("169.254."):
        continue  # берём только host -> vm
    m = re.search(rb"X-Access-Token:\s*([A-Fa-f0-9]{64})", d)
    if m:
        token = m.group(1)
        break

if not token:
    print("RESULT: токен в окне захвата не найден — пробовать нечего")
    sys.exit(0)

h12 = hashlib.sha256(token).hexdigest()[:12]
print(f"RESULT: токен пойман с провода, len={len(token)}, sha256[:12]={h12}")

def mask(s):
    return re.sub(r"[A-Za-z0-9+/_\-.]{20,}",
                  lambda m: f"<MASKED:{len(m.group(0))}>", s)

def describe_body(body, ctype):
    if not body:
        return "пусто"
    if "json" in ctype:
        try:
            obj = json.loads(body)
        except Exception:
            return "JSON(битый): " + mask(body[:80].decode("latin-1"))
        if isinstance(obj, dict):
            return "JSON-ключи: " + ",".join(sorted(obj.keys())[:20])
        if isinstance(obj, list):
            extra = ""
            if obj and isinstance(obj[0], dict):
                extra = ", ключи 1-го: " + ",".join(sorted(obj[0].keys())[:20])
            return f"JSON-список из {len(obj)} элементов{extra}"
        return f"JSON, тип {type(obj).__name__}"
    if "text" in ctype or not ctype:
        txt = body.decode("latin-1")
        if txt.lstrip().startswith(("# HELP", "# TYPE")) or "go_gc" in txt or "process_" in txt:
            names = set()
            for ln in txt.splitlines():
                if ln.startswith("#"):
                    continue
                names.add(ln.split("{")[0].split(" ")[0])
            return f"prometheus-метрики, строк={len(txt.splitlines())}, имена={sorted(names)[:25]}"
        return "text: " + mask(txt[:80])
    return f"{ctype}, len={len(body)}"

ROUTES = ["/", "/metrics", "/health", "/healthz", "/readyz", "/status", "/specs",
          "/sandbox", "/sandbox/specs", "/version", "/info", "/config", "/api",
          "/v1", "/v1/specs", "/files", "/file", "/logs", "/exec", "/execute",
          "/envs", "/env", "/stats", "/openapi.json", "/swagger", "/docs",
          "/debug", "/debug/pprof/"]

print("=== с токеном (только собственный envd 127.0.0.1:49983, GET) ===")
for r in ROUTES:
    try:
        c = http.client.HTTPConnection("127.0.0.1", 49983, timeout=3)
        c.request("GET", r, headers={"X-Access-Token": token.decode("latin-1"),
                                     "Connection": "close"})
        resp = c.getresponse()
        body = resp.read(4096)
        ctype = resp.getheader("Content-Type") or ""
        print(f"  {r:20} -> {resp.status}  ct={ctype or '-'}  len={len(body)}  {describe_body(body, ctype)}")
        c.close()
    except Exception as e:
        print(f"  {r:20} -> ОШИБКА {type(e).__name__}")
    time.sleep(0.05)

print("=== контроль без токена (для контраста) ===")
for r in ["/", "/metrics", "/specs", "/health"]:
    try:
        c = http.client.HTTPConnection("127.0.0.1", 49983, timeout=3)
        c.request("GET", r, headers={"Connection": "close"})
        resp = c.getresponse()
        resp.read(512)
        print(f"  {r:20} -> {resp.status}")
        c.close()
    except Exception as e:
        print(f"  {r:20} -> ОШИБКА {type(e).__name__}")
