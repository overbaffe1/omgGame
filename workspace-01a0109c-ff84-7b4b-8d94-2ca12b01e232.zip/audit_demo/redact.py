#!/usr/bin/env python3
"""Читает вывод tcpdump -A из stdin, маскирует ВСЁ секрето-подобное В ПАМЯТИ
и печатает только структуру трафика (методы, пути, статусы, имена заголовков).
Никаких значений секретов наружу, ничего не пишется на диск."""
import re
import sys

raw = sys.stdin.buffer.read().decode("latin-1")

rules = [
    ("long-token/b64", re.compile(r"[A-Za-z0-9+/_-]{40,}={0,2}"), "[REDACTED]"),
    ("e2b-token",      re.compile(r"e2b_[A-Za-z0-9_-]{6,}"), "[REDACTED]"),
    ("query-token",    re.compile(r"([?&][A-Za-z0-9_-]*[Tt]oken[A-Za-z0-9_-]*=)[^&\s]+"), r"\1[REDACTED]"),
    ("auth-header",    re.compile(r"(Authorization:\s*)[^\r\n]*", re.I), r"\1[REDACTED]"),
    ("x-auth-header",  re.compile(r"([Xx]-[A-Za-z0-9_-]*[Aa]uth[A-Za-z0-9_-]*:\s*)[^\r\n]*"), r"\1[REDACTED]"),
    ("cookie-header",  re.compile(r"(Cookie:\s*)[^\r\n]*", re.I), r"\1[REDACTED]"),
    ("token-field",    re.compile(r"(\"[A-Za-z0-9_-]*[Tt]oken[A-Za-z0-9_-]*\"\s*:\s*)\"[^\"]*\""), r'\1"[REDACTED]"'),
    ("access-field",   re.compile(r"(\"[Aa]ccess[A-Za-z0-9_-]*\"\s*:\s*)\"[^\"]*\""), r'\1"[REDACTED]"'),
    ("signature-field",re.compile(r"(\"[A-Za-z0-9_-]*[Ss]ignature[A-Za-z0-9_-]*\"\s*:\s*)\"[^\"]*\""), r'\1"[REDACTED]"'),
]

counts = {}
safe = raw
for name, rx, rep in rules:
    safe, n = rx.subn(rep, safe)
    counts[name] = n

# только печатаемые символы
safe = "".join(c if 32 <= ord(c) < 127 else "." for c in safe)

BENIGN = {
    "host", "content-type", "content-length", "user-agent", "accept", "connection",
    "accept-encoding", "date", "server", "cache-control", "content-encoding",
    "transfer-encoding", "upgrade", "sec-websocket-key", "sec-websocket-accept",
    "sec-websocket-version", "sec-websocket-extensions", "sec-websocket-protocol",
}

reqs, resps, benign, other = [], [], set(), set()
sig_hits = 0
for ln in safe.splitlines():
    ln = ln.strip()
    m = re.match(r"(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS|CONNECT)\s+(\S+)\s+(HTTP/\d\.\d)", ln)
    if m:
        reqs.append((m.group(1), m.group(2).split("?")[0][:60], m.group(3)))
        continue
    m = re.match(r"(HTTP/\d\.\d)\s+(\d{3})", ln)
    if m:
        resps.append((m.group(1), m.group(2)))
        continue
    m = re.match(r"([A-Za-z][A-Za-z0-9-]{1,40}):\s*(.*)$", ln)
    if m:
        name, val = m.group(1).lower(), m.group(2)
        if name in BENIGN:
            benign.add(f"{name}: {val[:25]}")
        else:
            other.add(name)
        if re.search(r"sig", name + val, re.I):
            sig_hits += 1

print("=== запросы (метод / путь / версия) ===")
for r in reqs[:15]:
    print("  ", *r)
print("=== ответы (версия / статус) ===")
for r in resps[:15]:
    print("  ", *r)
print("=== заголовки с безопасными значениями ===")
for h in sorted(benign):
    print("  ", h)
print("=== прочие заголовки (только имена, значения скрыты) ===")
print("   ", ", ".join(sorted(other)) or "(нет)")
print("=== что скрыла маска ===")
for k, v in counts.items():
    if v:
        print(f"   {k}: {v} вхождений")
print(f"=== строк с упоминанием sign/signature: {sig_hits} ===")
