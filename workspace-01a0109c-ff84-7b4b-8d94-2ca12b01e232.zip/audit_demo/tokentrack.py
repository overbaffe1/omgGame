#!/usr/bin/env python3
"""Следит за токенами НЕ раскрывая их: для каждого X-Access-Token и каждого
long-значения печатает только sha256[:12], длину и направление. Сам токен
не печатается и не сохраняется никуда."""
import re, sys, hashlib, collections

raw = sys.stdin.buffer.read().decode("latin-1")
frames, cur = [], None
for ln in raw.splitlines():
    if ln.startswith("IP "):
        if cur is not None: frames.append(cur)
        cur = [ln, bytearray()]; continue
    m = re.match(r"^\s*0x[0-9a-fA-F]+:\s+((?:[0-9a-fA-F]{2} ?){1,16})", ln)
    if m and cur is not None:
        cur[1].extend(bytes.fromhex(m.group(1).replace(" ", "")))
if cur is not None: frames.append(cur)

def tcp_data(fr):
    if len(fr) < 54 or fr[12:14] != b"\x08\x00": return b""
    ihl = (fr[14] & 0x0F) * 4
    tcp = 14 + ihl
    doff = ((fr[tcp + 12] >> 4) & 0x0F) * 4
    return fr[tcp + doff:]

seen = collections.Counter()   # hash -> сколько раз
events = []                    # (label, h12, length)
for hdr, fr in frames:
    d = tcp_data(fr)
    if not d: continue
    src = re.search(r"IP ([\d.]+)\.(\d+) > ([\d.]+)\.(\d+)", hdr)
    direction = "host->vm" if not src.group(1).startswith("169.254.") else "vm->host"
    for m in re.finditer(rb"X-Access-Token:\s*([A-Za-z0-9+/_-]{30,})", d):
        v = m.group(1)
        h = hashlib.sha256(v).hexdigest()[:12]
        seen["tok:" + h] += 1
        events.append((f"XAT {direction}", h, len(v)))
    for m in re.finditer(rb"[A-Za-z0-9]{64,}", d):
        v = m.group(0)
        h = hashlib.sha256(v).hexdigest()[:12]
        seen["long64:" + h] += 1
        events.append((f"64+hex {direction}", h, len(v)))

print("=== отпечатки (sha256[:12]) ===")
for e in events:
    print("   ", e[0], "h12=", e[1], "len=", e[2])
print("=== сколько РАЗЛИЧНЫХ значений по категориям ===")
for k, n in sorted(seen.items()):
    print(f"   {k}: встречался {n} раз")
