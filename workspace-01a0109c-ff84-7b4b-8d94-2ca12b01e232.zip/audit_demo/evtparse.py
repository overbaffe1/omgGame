#!/usr/bin/env python3
"""evtparse.py — структура JSON-событий envd -> хост (192.0.2.1:80).
Печатаются ТОЛЬКО имена ключей и длины; значения всегда маскируются."""
import re, sys, json, collections

raw = sys.stdin.buffer.read().decode("latin-1")
frames, cur = [], None
for ln in raw.splitlines():
    if ln.startswith("IP "):
        if cur is not None:
            frames.append(cur)
        cur = [ln, bytearray()]
        continue
    m = re.match(r"^\s*0x[0-9a-fA-F]+:\s+((?:[0-9a-fA-F]{2} ?){1,16})", ln)
    if m and cur is not None:
        cur[1].extend(bytes.fromhex(m.group(1).replace(" ", "")))
if cur is not None:
    frames.append(cur)

def tcp_data(fr):
    if len(fr) < 54 or fr[12:14] != b"\x08\x00":
        return b""
    ihl = (fr[14] & 0x0F) * 4
    tcp = 14 + ihl
    doff = ((fr[tcp + 12] >> 4) & 0x0F) * 4
    return fr[tcp + doff:]

streams = {}   # src_port -> bytearray (грубая сборка TCP-потока vm->host)
order = []
for hdr, fr in frames:
    d = tcp_data(fr)
    if not d:
        continue
    s = re.search(r"IP ([\d.]+)\.(\d+) > ([\d.]+)\.(\d+)", hdr)
    if not s:
        continue
    sip, sport, dip, dport = s.group(1), int(s.group(2)), s.group(3), int(s.group(4))
    if sip.startswith("169.254.") and dport == 80:   # только envd -> events
        if sport not in streams:
            order.append(sport)
        streams.setdefault(sport, bytearray()).extend(d)

def keynames(obj, depth=0, acc=None):
    acc = acc or []
    if depth > 2:
        return acc
    if isinstance(obj, dict):
        for k, v in obj.items():
            acc.append(k)
            keynames(v, depth + 1, acc)
    elif isinstance(obj, list) and obj:
        keynames(obj[0], depth + 1, acc)
    return acc

stats = collections.Counter()
examples = {}
for sport in order:
    buf = bytes(streams[sport])
    stats["потоков"] += 1
    stats["байт_всего"] += len(buf)
    # ищем JSON-объекты: {...} верхнего уровня
    for m in re.finditer(rb"\{[^{}]*\}", buf):
        try:
            obj = json.loads(m.group(0))
        except Exception:
            stats["не-JSON"] += 1
            continue
        stats["JSON-объектов"] += 1
        kn = keynames(obj)
        ktuple = tuple(kn[:8])
        stats["форма_ключей:" + str(ktuple)] += 1
        # длина самого длинного строкового значения (маска)
        def maxstr(o):
            if isinstance(o, str):
                return len(o)
            if isinstance(o, dict):
                return max([maxstr(v) for v in o.values()] + [0])
            if isinstance(o, list):
                return max([maxstr(v) for v in o] + [0])
            return 0
        stats["макс_длина_строки_в_объекте:" + str(maxstr(obj))] += 1

for k, v in sorted(stats.items()):
    print(f"   {k}: {v}")
