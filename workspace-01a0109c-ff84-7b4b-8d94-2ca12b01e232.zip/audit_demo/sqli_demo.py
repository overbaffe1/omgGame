import sqlite3
db = sqlite3.connect('/home/user/audit_demo/users.db')
c = db.cursor()
c.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)")
c.execute("DELETE FROM users")
c.executemany("INSERT INTO users (username,password) VALUES (?,?)",
              [("admin","hunter2"),("alice","wonderland"),("bob","builder")])
db.commit()

def vulnerable_login(username, password):
    # так делать нельзя: строка подставляется в SQL напрямую
    q = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    print("SQL:", q)
    return c.execute(q).fetchall()

print("== легитимный вход с неверным паролем ==")
print("rows:", vulnerable_login("admin", "wrong"))
print()
print("== SQL-инъекция: password = ' OR '1'='1 ==")
print("rows:", vulnerable_login("admin", "' OR '1'='1"))
