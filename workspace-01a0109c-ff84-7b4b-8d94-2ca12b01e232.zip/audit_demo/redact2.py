#!/usr/bin/env python3
"""Парсит вывод tcpdump -XX: собирает пакеты из hex, восстанавливает точные байты,
маскирует ВСЁ секрето-подобное в памяти, печатает только структуру + длины
вырезанных значений (сами значения не печатаются никогда). Диск не используется."""
import re
import sys

raw = sys.stdin.buffer.read().decode("latin-1")

# --- сегментация на пакеты по заголовкам tcpdump ---
packets, cur = [], None
for ln in raw.splitlines():
    if ln.startswith("IP ") or ln.startswith("Ethernet ") or re.match(r"\d\d:\d\d:\d\d", ln):
        if cur is not None:
            packets.append(cur)
        cur = bytearray()
        continue
    m = re.match(r"^\s*0x[0-9a-fA-F]+:\s+([0-9a-fA-F]{2}(?:\s+[0-9a-fA-F]{2}){0,15})", ln)
    if m and cur is not None:
        for h in m.group(1).split():
            cur.append(int(h, 16))
if cur is not None:
    packets.append(cur)

diag = {"HTTP/": 0, "Authorization": 0, "Bearer": 0, "GET ": 0, "POST ": 0,
        "e2b_": 0, "sig": 0, "{": 0}
token_lens, auth_lens = [], []

def m_token(m):
    token_lens.append(len(m.group(0)))
    return "[REDACTED]"

def m_auth(m):
    auth_lens.append(len(m.group(2)))
    return f"{m.group(1)}[REDACTED len={len(m.group(2))}]"

rules = [
    ("long-token/b64", re.compile(r"[A-Za-z0-9+/_-]{40,}={0,2}"), m_token),
    ("e2b-token",      re.compile(r"e2b_[A-Za-z0-9_-]{6,}"), lambda m: "[REDACTED]"),
    ("query-token",    re.compile(r"([?&][A-Za-z0-9_-]*[Tt]oken[A-Za-z0-9_-]*=)[^&\s]+"), r"\1[REDACTED]"),
    ("auth-header",    re.compile(r"(Authorization:\s*)([^\r\n]+)", re.I), m_auth),
    ("x-auth-header",  re.compile(r"([Xx]-[A-Za-z0-9_-]*[Aa]uth[A-Za-z0-9_-]*:\s*)([^\r\n]+)"), m_auth),
    ("cookie-header",  re.compile(r"(Cookie:\s*)([^\r\n]+)", re.I), lambda m: f"{m.group(1)}[REDACTED]"),
    ("token-field",    re.compile(r"(\"[A-Za-z0-9_-]*[Tt]oken[A-Za-z0-9_-]*\"\s*:\s*)\"[^\"]*\""), r'\1"[REDACTED]"'),
    ("access-field",   re.compile(r"(\"[Aa]ccess[A-Za-z0-9_-]*\"\s*:\s*)\"[^\"]*\""), r'\1"[REDACTED]"'),
]

counts, reqs, resps, benign, other = {}, [], [], set(), set()
BENIGN = {"host", "content-type", "content-length", "user-agent", "accept", "connection",
          "accept-encoding", "date", "server", "cache-control", "content-encoding",
          "transfer-encoding", "upgrade", "te", "keep-alive"}

for p in packets:
    if not p:
        continue
    text = p.decode("latin-1")
    low = text.lower()
    for k in diag:
        diag[k] += low.count(k.lower())
    safe = text
    for name, rx, rep in rules:
        safe, n = rx.subn(rep, safe)
        counts[name] = counts.get(name, 0) + n
    for ln in safe.splitlines():
        m = re.match(r"(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS|CONNECT)\s+(\S+)\s+(HTTP/\d\.\d)", ln)
        if m:
            reqs.append((m.group(1), m.group(2).split("?")[0][:60], m.group(3)))
            continue
        m = re.match(r"(HTTP/\d\.\d)\s+(\d{3})", ln)
        if m:
            resps.append((m.group(1), m.group(2)))
            continue
        m = re.match(r"([A-Za-z][A-Za-z0-9-]{1,40}):\s*(.*)$", ln)
        if m:
            name, val = m.group(1).lower(), m.group(2)
            if name in BENIGN:
                benign.add(f"{name}: {val[:25]}")
            else:
                other.add(name)

print("=== диагностика: что встречалось (счётчики, значений не показываю) ===")
for k, v in diag.items():
    if v:
        print(f"   {k}: {v}")
print("=== запросы (метод / путь / версия) ===")
for r in reqs[:15]:
    print("  ", *r)
print("=== ответы (версия / статус) ===")
for r in resps[:15]:
    print("  ", *r)
print("=== заголовки с безопасными значениями ===")
for h in sorted(benign):
    print("  ", h)
print("=== прочие заголовки (только имена) ===")
print("   ", ", ".join(sorted(other)) or "(нет)")
print("=== длины вырезанных значений (первые 20) ===")
print("   auth-значения:", auth_lens[:10] or "(не встретились)")
print("   длинные строки:", token_lens[:20] or "(нет)")
print("=== сколько чего скрыто ===")
for k, v in counts.items():
    if v:
        print(f"   {k}: {v}")
