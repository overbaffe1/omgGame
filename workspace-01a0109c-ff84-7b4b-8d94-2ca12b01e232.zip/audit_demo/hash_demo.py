import hashlib, time
secret = "1337"  # 4-значный PIN
h = hashlib.md5(secret.encode()).hexdigest()
print("target md5:", h)
t0 = time.time()
found = None
for i in range(10000):
    if hashlib.md5(f"{i:04d}".encode()).hexdigest() == h:
        found = f"{i:04d}"; break
print(f"PIN восстановлен перебором: {found} за {time.time()-t0:.3f} c")
