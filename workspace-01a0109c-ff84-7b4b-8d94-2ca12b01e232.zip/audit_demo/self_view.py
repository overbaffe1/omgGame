import json
from http.server import BaseHTTPRequestHandler, HTTPServer

class H(BaseHTTPRequestHandler):
    def do_GET(self):
        rec = {"path": self.path, "client": self.client_address,
               "headers": dict(self.headers.items())}
        with open("/home/user/outside_view.txt", "w") as f:
            f.write(json.dumps(rec, indent=2))
        body = b"hello from inside the VM"
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass

HTTPServer(("0.0.0.0", 8085), H).serve_forever()
