#!/usr/bin/env python3
"""tokentest2.py — уточнение по маршрутам envd с тем же токеном (только GET,
только собственный envd 127.0.0.1:49983). Токен с провода, наружу не выходит."""
import re, sys, json, http.client, hashlib, time

raw = sys.stdin.buffer.read().decode("latin-1")
frames, cur = [], None
for ln in raw.splitlines():
    if ln.startswith("IP "):
        if cur is not None:
            frames.append(cur)
        cur = [ln, bytearray()]
        continue
    m = re.match(r"^\s*0x[0-9a-fA-F]+:\s+((?:[0-9a-fA-F]{2} ?){1,16})", ln)
    if m and cur is not None:
        cur[1].extend(bytes.fromhex(m.group(1).replace(" ", "")))
if cur is not None:
    frames.append(cur)

def tcp_data(fr):
    if len(fr) < 54 or fr[12:14] != b"\x08\x00":
        return b""
    ihl = (fr[14] & 0x0F) * 4
    tcp = 14 + ihl
    doff = ((fr[tcp + 12] >> 4) & 0x0F) * 4
    return fr[tcp + doff:]

token = None
for hdr, fr in frames:
    d = tcp_data(fr)
    if not d:
        continue
    s = re.search(r"IP ([\d.]+)\.", hdr)
    if s and s.group(1).startswith("169.254."):
        continue
    m = re.search(rb"X-Access-Token:\s*([A-Fa-f0-9]{64})", d)
    if m:
        token = m.group(1)
        break

if not token:
    print("RESULT: токен в окне захвата не найден")
    sys.exit(0)

h12 = hashlib.sha256(token).hexdigest()[:12]
print(f"RESULT: токен пойман, len={len(token)}, sha256[:12]={h12}")

def mask(s):
    return re.sub(r"[A-Za-z0-9+/_\-.]{20,}",
                  lambda m: f"<MASKED:{len(m.group(0))}>", s)

def describe_body(body, ctype):
    if not body:
        return "пусто"
    if "json" in ctype:
        try:
            obj = json.loads(body)
        except Exception:
            return "JSON(битый): " + mask(body[:100].decode("latin-1"))
        if isinstance(obj, dict):
            return "JSON-ключи: " + ",".join(sorted(obj.keys())[:20])
        if isinstance(obj, list):
            extra = ""
            if obj and isinstance(obj[0], dict):
                extra = ", ключи 1-го: " + ",".join(sorted(obj[0].keys())[:20])
            return f"JSON-список из {len(obj)} элементов{extra}"
        return f"JSON, тип {type(obj).__name__}"
    if "text" in ctype or not ctype:
        return "text: " + mask(body.decode("latin-1")[:120])
    return f"{ctype}, len={len(body)}"

PROBES = [
    "/files?path=%2Fetc%2Fhostname",
    "/files?path=etc/hostname",
    "/files/%2Fetc%2Fhostname",
    "/files/etc/hostname",
    "/envs?name=E2B_SANDBOX_ID",
    "/envs/E2B_SANDBOX_ID",
    "/envs/all",
    "/metrics?format=prometheus",
    "/dir?path=%2F",
    "/tree",
]

print("=== уточняющие пробы (GET, только собственный envd) ===")
for r in PROBES:
    try:
        c = http.client.HTTPConnection("127.0.0.1", 49983, timeout=3)
        c.request("GET", r, headers={"X-Access-Token": token.decode("latin-1"),
                                     "Connection": "close"})
        resp = c.getresponse()
        body = resp.read(4096)
        ctype = resp.getheader("Content-Type") or ""
        print(f"  {r:34} -> {resp.status}  ct={ctype or '-'}  len={len(body)}  {describe_body(body, ctype)}")
        c.close()
    except Exception as e:
        print(f"  {r:34} -> ОШИБКА {type(e).__name__}")
    time.sleep(0.05)
