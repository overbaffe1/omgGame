#!/usr/bin/env python3
"""
passive_sniffer_B.py — безустановочный пассивный захват трафика на eth0.

Назначение: добыть ОТПЕЧАТОК X-Access-Token песочницы B для сравнения
с отпечатком песочницы A (f00a7891816d), НЕ печатая само значение токена.

Правила: только чтение, без установки пакетов, без исходящих запросов.
Вывод: счётчики, peer-IP, длина и sha256[:12] каждого найденного токена.

Запуск:  python3 passive_sniffer_B.py 60 eth0
Если вывод RAW_SOCKET_DENIED — попробуй: sudo python3 passive_sniffer_B.py 60 eth0
"""
import socket, struct, hashlib, sys, time, re

DURATION = int(sys.argv[1]) if len(sys.argv) > 1 else 60
IFACE = sys.argv[2] if len(sys.argv) > 2 else "eth0"
TOKEN_RE = re.compile(rb"X-Access-Token:\s*([^\r\n]+)", re.IGNORECASE)

def fp(data):
    return hashlib.sha256(data).hexdigest()[:12]

try:
    s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))
    s.bind((IFACE, 0))
except PermissionError:
    print("RAW_SOCKET_DENIED: нет CAP_NET_RAW - попробуй запуск через sudo; "
          "если sudo тоже нет, пассивный контроль возможен только с хоста платформы.")
    sys.exit(2)
except OSError as e:
    print("RAW_SOCKET_ERROR:", e)
    sys.exit(2)

s.settimeout(1.0)
start = time.time()
frames = 0
ip_frames = 0
tcp_segments = 0
http_segments = 0
peers = set()
tokens = {}          # fp -> {"count": n, "len": l}
while time.time() - start < DURATION:
    try:
        frame, _ = s.recvfrom(65535)
    except socket.timeout:
        continue
    except OSError as e:
        print("CAPTURE_ERROR:", e)
        break
    frames += 1
    if len(frame) < 54:
        continue
    eth_type = struct.unpack("!H", frame[12:14])[0]
    if eth_type != 0x0800:          # только IPv4
        continue
    ip_frames += 1
    ihl = (frame[14] & 0x0F) * 4
    proto = frame[14 + 9]
    if proto != 6:                  # только TCP
        continue
    src_ip = socket.inet_ntoa(frame[14 + 12:14 + 16])
    dst_ip = socket.inet_ntoa(frame[14 + 16:14 + 20])
    tcp_off = 14 + ihl
    doff = (frame[tcp_off + 12] >> 4) * 4
    payload = frame[tcp_off + doff:]
    if not payload:
        continue
    tcp_segments += 1
    peers.add(src_ip)
    peers.add(dst_ip)
    head = payload[:16]
    if (head.startswith(b"GET ") or head.startswith(b"POST ")
            or head.startswith(b"PUT ") or head.startswith(b"HEAD ")
            or head.startswith(b"HTTP/") or b"X-Access-Token" in payload):
        http_segments += 1
        for m in TOKEN_RE.finditer(payload):
            val = m.group(1).strip()
            if not val:
                continue
            key = fp(val)
            rec = tokens.get(key)
            if rec is None:
                tokens[key] = {"count": 1, "len": len(val)}
            else:
                rec["count"] += 1
                rec["len"] = len(val)

print(f"capture_done duration_s={int(time.time()-start)} frames={frames} "
      f"ipv4={ip_frames} tcp_with_payload={tcp_segments} http_like={http_segments}")
print("peers: " + (", ".join(sorted(peers)) or "(none)"))
if not tokens:
    print("tokens_found: none")
else:
    print("tokens_found:")
    for key in sorted(tokens):
        r = tokens[key]
        print(f"  fingerprint_sha256_12={key} value_len={r['len']} seen={r['count']}")
