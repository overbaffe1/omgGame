# ПРОМТ ДЛЯ ВТОРОГО АГЕНТА — скопируй ВСЁ ниже целиком в новый диалог

---

Ты — агент в песочнице B. Задача: тест сетевой изоляции песочниц платформы.

**Контекст.** Один и тот же владелец имеет две песочницы. Эта песочница — B.
Песочница A (другой диалог) имеет link-local IP `169.254.0.21` и публичный адрес
`https://49999-i8f4b59uq9w4ngg75fda5.e2b.app`. Нужно определить, может ли код в B
получить доступ к данным в A (файлы, сервисы).

**Жёсткие правила:**
1. Только чтение. Ничего не изменяй; единственный создаваемый файл — файл результатов.
2. Только ОДИН целевой IP: `169.254.0.21` (это песочница того же владельца).
   НИКАКОГО сканирования диапазонов и других адресов.
3. Если встретишь что-то похожее на секрет/токен — НИКОГДА не записывай значение:
   только длину и sha256-префикс (12 hex).
4. Если какой-то сервис окажется доступен — НЕ эксплуатируй его, просто зафиксируй.
5. Не устанавливай пакеты. Если инструмента нет — пропусти шаг с пометкой.
6. Сомневаешься в допустимости шага — пропусти его и зафиксируй это в отчёте.

**Шаги:**
1. Сохрани код ниже в файл `/home/user/isolation_probe.py` и выполни:
   `python3 /home/user/isolation_probe.py`
2. Дождись завершения (≈60–90 секунд). Результаты автоматически запишутся
   в `/home/user/isolation_test_results.md`.
3. Выведи в чат: (а) список открытых портов и были ли это самопробы;
   (б) код ответа на публичный URL A; (в) совпал ли отпечаток токена B с A;
   (г) итоговый вердикт из сводки скрипта.

**Как читать результаты (для тебя и владельца):**
- Здоровая платформа: все порты closed/filtered (или это самопробы B), публичный
  URL A → 403, в пассивном трафике только B и агенты хоста, отпечаток токена B
  ≠ `f00a7891816d`. Тогда пути из B к данным A НЕТ.
- Любой реально открытый порт A или 200 с публичного URL A → КРИТИЧЕСКИЙ результат.
- Совпадение отпечатков токенов → токены не уникальны на песочницу (важно для
  техкоманды, хотя сам по себе путь это не открывает).
- ВАЖНАЯ ТОНКОСТЬ: платформа может выдавать каждой песочнице один и тот же
  link-local IP `169.254.0.21` на изолированных сегментах. Если у B тот же IP —
  прямые пробы попадают в саму B (самопроб, контроль), и о A они ничего не говорят.
  Скрипт это определяет автоматически и помечает.

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""isolation_probe.py — тест изоляции песочниц (выполняется ВНУТРИ песочницы B).
Только чтение. Один целевой IP (песочница A того же владельца). Секреты маскируются."""
import os, re, socket, hashlib, subprocess, http.client

TARGET_IP    = "169.254.0.21"   # IP песочницы A (узнан внутри песочницы A)
TARGET_PORTS = [22, 80, 443, 49983, 49999, 8888]
URL_A        = "https://49999-i8f4b59uq9w4ngg75fda5.e2b.app"  # публичный адрес A
FP_A         = "f00a7891816d"   # sha256[:12] токена песочницы A (ОТПЕЧАТОК, не значение)

log_lines = []
def log(s=""):
    print(s)
    log_lines.append(s)

def sh(cmd, timeout=15):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return (r.returncode, (r.stdout or "") + (r.stderr or ""))
    except Exception as e:
        return (-1, f"ошибка: {e}")

def mask(s):
    return re.sub(r"[A-Za-z0-9+/_\-.]{24,}", lambda m: f"<MASKED:{len(m.group(0))}>", s)

log("=" * 72)
log("ТЕСТ ИЗОЛЯЦИИ ПЕСОЧНИЦ — выполняется в песочнице B")
log("Вопрос: есть ли из B путь к данным песочницы A?")
log("=" * 72)

# --- 1. Идентификация B ---
log("\n[1] ИДЕНТИФИКАЦИЯ ПЕСОЧНИЦЫ B:")
rc, s = sh("cat /run/e2b/.E2B_SANDBOX_ID /run/e2b/.E2B_TEMPLATE_ID 2>/dev/null")
if s.strip():
    parts = s.strip().splitlines()
    log(f"    sandbox_id B  = {parts[0] if len(parts) > 0 else '?'}")
    log(f"    template_id B = {parts[1] if len(parts) > 1 else '?'}")
else:
    rc, s = sh("hostname")
    log(f"    hostname: {s.strip()}")

# --- 2. Сеть B ---
log("\n[2] СЕТЬ ПЕСОЧНИЦЫ B (адреса, маршруты, ARP-соседи):")
rc, s = sh("ip -4 addr show 2>/dev/null | grep inet; echo '--- route ---'; ip route 2>/dev/null; echo '--- neigh ---'; ip neigh 2>/dev/null")
log(s.rstrip() or "    (ip-инструменты недоступны)")
rc, s2 = sh("hostname -I 2>/dev/null")
own_ips = set(re.findall(r"inet (\d+\.\d+\.\d+\.\d+)/", s)) | set(re.findall(r"\b(\d+\.\d+\.\d+\.\d+)\b", s2))
same_ip = TARGET_IP in own_ips
if same_ip:
    log(f"    ВАЖНО: у B тот же link-local IP {TARGET_IP}!")
    log("    Прямые пробы ниже попадут в САМУ B (контрольные самопробы) и о A ничего не говорят.")
    log("    Решающие тесты: [5] пассивный трафик, [8] публичный URL A, [10] отпечаток токена.")

# --- 3. env-переменные B ---
log("\n[3] ENV-ПЕРЕМЕННЫЕ B (значения длиннее 24 симв. маскируются):")
found_env = False
for k in sorted(os.environ):
    if k.startswith("E2B_") or "TOKEN" in k.upper() or "KEY" in k.upper() or "SECRET" in k.upper():
        v = os.environ[k]
        log(f"    {k} = {v if len(v) < 24 else mask(v)}")
        found_env = True
if not found_env:
    log("    переменных E2B_/TOKEN/KEY нет")

# --- 4. Файлы с возможными кредами в B ---
log("\n[4] ФАЙЛЫ С ВОЗМОЖНЫМИ КРЕДАМИ В B:")
rc, s = sh("ls -la /run/e2b /root/.e2b /root/.config/e2b 2>/dev/null | head -20; "
           "find / -maxdepth 3 \\( -name '*.env' -o -name '.env' -o -name 'credentials*' \\) "
           "-not -path '/proc/*' -not -path '/sys/*' 2>/dev/null | head -5")
log(s.rstrip() or "    ничего подозрительного")

# --- 5. Пассивный трафик B ---
log("\n[5] ПАССИВНЫЙ ЗАХВАТ ТРАФИКА B (6 c, только чтение):")
rc, s = sh("sudo -n timeout 6 tcpdump -i eth0 -nn -t -c 200 2>/dev/null || "
           "timeout 6 tcpdump -i eth0 -nn -t -c 200 2>/dev/null || echo 'tcpdump недоступен'")
if "недоступен" in s:
    log("    tcpdump недоступен — шаг пропущен")
elif not s.strip():
    log("    трафика нет")
else:
    ips = sorted(set(re.findall(r"IP (\d+\.\d+\.\d+\.\d+)\.", s)))
    log(f"    замеченные IP: {ips}")
    first = s.strip().splitlines()[0]
    log(f"    пример: {first}")
    foreign = [i for i in ips if not i.startswith("169.254.") and not i.startswith("10.1")]
    log(f"    чужие IP (не хост-пул, не link-local): {foreign if foreign else 'нет'}")

# --- 6. TCP-порты A ---
log(f"\n[6] TCP-ПОРТЫ {TARGET_IP} — только connect(), без данных:")
opened = []
for p in TARGET_PORTS:
    sk = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sk.settimeout(2)
    try:
        sk.connect((TARGET_IP, p))
        tag = "САМОПРОБ B (контроль)" if same_ip else "ОТКРЫТ <-- важно!"
        log(f"    порт {p:6} -> {tag}")
        opened.append(p)
        sk.close()
    except Exception as e:
        log(f"    порт {p:6} -> closed/filtered ({type(e).__name__})")

# --- 7. HTTP-пробы ---
log(f"\n[7] HTTP-ПРОБЫ {TARGET_IP} (GET, только чтение, 3 c):")
for name, port, path in [("envd /health", 49983, "/health"),
                         ("envd / (без токена)", 49983, "/"),
                         ("code-interpreter /health", 49999, "/health"),
                         ("jupyter /api/status", 8888, "/api/status")]:
    try:
        c = http.client.HTTPConnection(TARGET_IP, port, timeout=3)
        c.request("GET", path, headers={"Connection": "close"})
        r = c.getresponse()
        body = mask(r.read(120).decode("latin-1", "replace"))
        note = " [самопроб B]" if same_ip else ""
        log(f"    {name:26} -> {r.status} {r.getheader('Content-Type') or ''} | {body[:80]}{note}")
        c.close()
    except Exception as e:
        log(f"    {name:26} -> {type(e).__name__}")

# --- 8. Публичный URL A через трафик-прокси ---
log("\n[8] ПУБЛИЧНЫЙ URL A ИЗ B (единственный честный путь между песочницами):")
rc, s = sh("curl -s -m 6 -o /dev/null -w '%{http_code}' " + URL_A + "/health || echo 'curl недоступен'")
code8 = s.strip()
log(f"    {URL_A}/health -> HTTP {code8}")

# --- 9. Метаданные облака из B ---
rc, s = sh("curl -s -m 4 -o /dev/null -w '%{http_code}' http://169.254.169.254/latest/meta-data/ || echo 'curl недоступен'")
log(f"\n[9] МЕТАДАННЫЕ ОБЛАКА из B: HTTP {s.strip()}")

# --- 10. Токен платформы в СВОЕЙ песочнице B (пассивно) ---
log("\n[10] ТОКЕН ПЛАТФОРМЫ В B (пассивный захват ~30 c, значение НЕ печатается):")
rc, s = sh("sudo -n timeout 30 tcpdump -i eth0 -nn -t -XX 'tcp port 49983' 2>/dev/null || "
           "timeout 30 tcpdump -i eth0 -nn -t -XX 'tcp port 49983' 2>/dev/null", timeout=40)
token_match = None
if not s.strip() or "permission" in s.lower():
    log("    tcpdump недоступен — шаг пропущен")
else:
    frames, cur = [], None
    for ln in s.splitlines():
        if ln.startswith("IP "):
            if cur is not None:
                frames.append(cur)
            cur = [ln, bytearray()]
            continue
        m = re.match(r"^\s*0x[0-9a-fA-F]+:\s+((?:[0-9a-fA-F]{2} ?){1,16})", ln)
        if m and cur is not None:
            cur[1].extend(bytes.fromhex(m.group(1).replace(" ", "")))
    if cur is not None:
        frames.append(cur)

    def tcp_data(fr):
        if len(fr) < 54 or fr[12:14] != b"\x08\x00":
            return b""
        ihl = (fr[14] & 0x0F) * 4
        tcp = 14 + ihl
        doff = ((fr[tcp + 12] >> 4) & 0x0F) * 4
        return fr[tcp + doff:]

    tokens = []
    for h, fr in frames:
        d = tcp_data(fr)
        if not d:
            continue
        ipm = re.search(r"IP ([\d.]+)\.", h)
        if ipm and ipm.group(1).startswith("169.254."):
            continue  # берём только host -> vm
        m = re.search(rb"X-Access-Token:\s*([A-Fa-f0-9]{64})", d)
        if m:
            tokens.append(m.group(1))
    if not tokens:
        log("    токен в окне не пойман (канал молчал) — шаг пропущен")
    else:
        fps = sorted({hashlib.sha256(t.lower()).hexdigest()[:12] for t in tokens})
        log(f"    поймано {len(tokens)} токенов, уникальные отпечатки sha256[:12]: {fps}")
        token_match = FP_A in fps
        if token_match:
            log("    *** СОВПАДЕНИЕ С ОТПЕЧАТКОМ ТОКЕНА A: токены НЕ уникальны на песочницу ***")
        else:
            log(f"    отпечаток A ({FP_A}) НЕ совпадает -> токен выдаётся на песочницу (изоляция подтверждена)")

# --- 11. Сводка ---
log("\n" + "=" * 72)
log("СВОДКА")
log("=" * 72)
real_open = [p for p in opened if not same_ip]
if same_ip:
    log(f"- Прямые пробы были самопробами B (тот же IP {TARGET_IP}): о A не говорят.")
    log(f"  У B самой открыты порты: {opened if opened else 'нет'}.")
if code8 == "200":
    log("- ПУБЛИЧНЫЙ URL A ОТВЕТИЛ 200 ИЗ B: КРИТИЧЕСКИЙ РЕЗУЛЬТАТ — путь между песочницами существует!")
elif code8 == "403":
    log("- Публичный URL A из B -> 403: трафик-прокси закрывает путь между песочницами (ожидаемо).")
elif code8 and code8 != "curl недоступен":
    log(f"- Публичный URL A из B -> {code8}: нестандартный ответ, зафиксируй как есть.")
if token_match is True:
    log("- Токены A и B совпали: НЕ уникальны на песочницу — передать техкоманде.")
elif token_match is False:
    log("- Токены A и B разные: выдаются на песочницу.")
else:
    log("- Сравнение токенов не удалось (канал молчал / нет прав).")
if not real_open and code8 != "200":
    log("- ИТОГ: сетевого пути из B к данным A НЕ ОБНАРУЖЕНО. Изоляция работает.")

with open("/home/user/isolation_test_results.md", "w") as f:
    f.write("# Результаты теста изоляции песочниц\n\n")
    f.write("Выполнено в песочнице B. Целевая песочница A: IP %s, URL %s\n\n" % (TARGET_IP, URL_A))
    f.write("\n".join(log_lines))
    f.write("\n")
print("\n[OK] Результаты записаны в /home/user/isolation_test_results.md")
```

**После выполнения:** выведи краткую сводку (открытые порты, код публичного URL,
совпадение отпечатков, вердикт) и укажи путь к файлу результатов.
